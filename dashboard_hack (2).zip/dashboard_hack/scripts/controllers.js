/*
var controllers=angular.module("controllers",[]);

controllers.controller("post",function($scope,$rootScope,$http){
  var badges_all=[]
  $http.get("/badges")
  .then(function(response){
    badges_all=response;
  });

  var categories=[];
  for(var i=0;i<badges_all.length();i++){
    console.log(badges_all[i].$.name);
  }



});
*/

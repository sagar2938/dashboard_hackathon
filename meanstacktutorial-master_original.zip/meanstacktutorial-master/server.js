// MEAN Stack RESTful API Tutorial - Contact List App

var express = require('express');
var app = express();
var mongojs = require('mongojs');
var db = mongojs('dashboard', ['results',"details"]);
var bodyParser = require('body-parser');

app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());

var obj={
  "_id": "1223",
  "_declaration": {
    "_attributes": {
      "version": "1.0",
      "encoding": "UTF-8"
    }
  },
  "pmd": {
    "_attributes": {
      "version": "5.4.0",
      "timestamp": "2016-11-18T21:13:45.930"
    },
    "file": [
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Account.java"
        },
        "violation": [

          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "11",
              "endcolumn": "23",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "state",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "11",
              "endcolumn": "21",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "zip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "country",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "11",
              "endcolumn": "23",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "phone",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "18",
              "endcolumn": "36",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "favouriteCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like favouriteCategoryId\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "11",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "favouriteCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "18",
              "endcolumn": "35",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "languagePreference",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like languagePreference\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "11",
              "endcolumn": "36",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "languagePreference",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "11",
              "endcolumn": "29",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "listOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "bannerOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "variable": "bannerName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "33",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setUsername",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "43",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setPassword",
              "variable": "password",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'password' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "45",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "49",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getEmail",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "51",
              "endline": "51",
              "begincolumn": "24",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setEmail",
              "variable": "email",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'email' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "51",
              "endline": "53",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setEmail",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "55",
              "endline": "57",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "59",
              "begincolumn": "28",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setFirstName",
              "variable": "firstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'firstName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "61",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "65",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "67",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setLastName",
              "variable": "lastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'lastName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "69",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "73",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getStatus",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "75",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setStatus",
              "variable": "status",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'status' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "77",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setStatus",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "79",
              "endline": "81",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "83",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setAddress1",
              "variable": "address1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'address1' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "85",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "89",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "91",
              "endline": "91",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setAddress2",
              "variable": "address2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'address2' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "91",
              "endline": "93",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "95",
              "endline": "97",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "99",
              "endline": "99",
              "begincolumn": "23",
              "endcolumn": "33",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setCity",
              "variable": "city",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'city' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "99",
              "endline": "101",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "103",
              "endline": "105",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "107",
              "begincolumn": "24",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setState",
              "variable": "state",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'state' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "109",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "111",
              "endline": "113",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "115",
              "begincolumn": "22",
              "endcolumn": "31",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setZip",
              "variable": "zip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'zip' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "117",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "119",
              "endline": "121",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "123",
              "begincolumn": "26",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setCountry",
              "variable": "country",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'country' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "125",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "127",
              "endline": "129",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getPhone",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "131",
              "endline": "131",
              "begincolumn": "24",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setPhone",
              "variable": "phone",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'phone' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "131",
              "endline": "133",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setPhone",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "135",
              "endline": "137",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getFavouriteCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "139",
              "endline": "139",
              "begincolumn": "45",
              "endcolumn": "63",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setFavouriteCategoryId",
              "variable": "favouriteCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like favouriteCategoryId\r\n"
          },
          {
            "_attributes": {
              "beginline": "139",
              "endline": "139",
              "begincolumn": "38",
              "endcolumn": "63",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setFavouriteCategoryId",
              "variable": "favouriteCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'favouriteCategoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "139",
              "endline": "141",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setFavouriteCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "143",
              "endline": "145",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getLanguagePreference",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "147",
              "endline": "147",
              "begincolumn": "44",
              "endcolumn": "61",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setLanguagePreference",
              "variable": "languagePreference",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like languagePreference\r\n"
          },
          {
            "_attributes": {
              "beginline": "147",
              "endline": "147",
              "begincolumn": "37",
              "endcolumn": "61",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setLanguagePreference",
              "variable": "languagePreference",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'languagePreference' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "147",
              "endline": "149",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setLanguagePreference",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "151",
              "endline": "153",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "isListOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "155",
              "endline": "155",
              "begincolumn": "29",
              "endcolumn": "46",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setListOption",
              "variable": "listOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'listOption' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "155",
              "endline": "157",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setListOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "159",
              "endline": "161",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "isBannerOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "163",
              "endline": "163",
              "begincolumn": "31",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setBannerOption",
              "variable": "bannerOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'bannerOption' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "163",
              "endline": "165",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setBannerOption",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "167",
              "endline": "169",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "getBannerName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "171",
              "endline": "171",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setBannerName",
              "variable": "bannerName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'bannerName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "171",
              "endline": "173",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Account",
              "method": "setBannerName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Cart.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "10",
              "endline": "94",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "ShortClassName",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortClassName",
              "priority": "4"
            },
            "_text": "\r\nAvoid short class names like Cart\r\n"
          },
          {
            "_attributes": {
              "beginline": "10",
              "endline": "94",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "10",
              "endline": "94",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "10",
              "endline": "94",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "21",
              "endcolumn": "27",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "variable": "itemMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "17",
              "endcolumn": "19",
              "rule": "UseConcurrentHashMap",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#UseConcurrentHashMap",
              "priority": "3"
            },
            "_text": "\r\nIf you run in Java5 or newer and have concurrent access, you should use the ConcurrentHashMap implementation\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "17",
              "endcolumn": "73",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "variable": "itemMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "31",
              "endcolumn": "38",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "variable": "itemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "17",
              "endcolumn": "67",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "variable": "itemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getCartItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "25",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getCartItemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getNumberOfItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getAllCartItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "5",
              "endcolumn": "35",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getAllCartItems",
              "variable": "allItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'allItems' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "43",
              "begincolumn": "33",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "containsItemId",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "45",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "containsItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "34",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "addItem",
              "variable": "isInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'isInStock' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "23",
              "endcolumn": "31",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "addItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'item' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "58",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "addItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "30",
              "endcolumn": "42",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "removeItemById",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "69",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "removeItemById",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "5",
              "endcolumn": "57",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "removeItemById",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "64",
              "endline": "64",
              "begincolumn": "7",
              "endcolumn": "18",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "removeItemById",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "67",
              "begincolumn": "14",
              "endcolumn": "31",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "removeItemById",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "71",
              "begincolumn": "41",
              "endcolumn": "53",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "incrementQuantityByItemId",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "74",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "incrementQuantityByItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "72",
              "endline": "72",
              "begincolumn": "5",
              "endcolumn": "54",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "incrementQuantityByItemId",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "73",
              "begincolumn": "5",
              "endcolumn": "32",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "incrementQuantityByItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "76",
              "endline": "76",
              "begincolumn": "35",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "setQuantityByItemId",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "76",
              "endline": "76",
              "begincolumn": "50",
              "endcolumn": "61",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "setQuantityByItemId",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'quantity' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "76",
              "endline": "79",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "setQuantityByItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "77",
              "endline": "77",
              "begincolumn": "5",
              "endcolumn": "54",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "setQuantityByItemId",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "78",
              "begincolumn": "5",
              "endcolumn": "34",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "setQuantityByItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "92",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "82",
              "begincolumn": "27",
              "endcolumn": "45",
              "rule": "BigIntegerInstantiation",
              "ruleset": "Basic",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/basic.html#BigIntegerInstantiation",
              "priority": "3"
            },
            "_text": "\r\nDont create instances of already existing BigInteger and BigDecimal (ZERO, ONE, TEN)\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "89",
              "begincolumn": "7",
              "endcolumn": "59",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "variable": "subTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'subTotal' (lines '82'-'89').\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "83",
              "begincolumn": "5",
              "endcolumn": "38",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "variable": "items",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'items' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "85",
              "endline": "85",
              "begincolumn": "7",
              "endcolumn": "49",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "7",
              "endcolumn": "36",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'item' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "19",
              "endcolumn": "36",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "87",
              "begincolumn": "7",
              "endcolumn": "48",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "variable": "listPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'listPrice' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "87",
              "begincolumn": "30",
              "endcolumn": "48",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "88",
              "endline": "88",
              "begincolumn": "29",
              "endcolumn": "82",
              "rule": "AvoidInstantiatingObjectsInLoops",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#AvoidInstantiatingObjectsInLoops",
              "priority": "3"
            },
            "_text": "\r\nAvoid instantiating new objects inside loops\r\n"
          },
          {
            "_attributes": {
              "beginline": "88",
              "endline": "88",
              "begincolumn": "7",
              "endcolumn": "82",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'quantity' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "88",
              "endline": "88",
              "begincolumn": "59",
              "endcolumn": "80",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "89",
              "begincolumn": "18",
              "endcolumn": "59",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "89",
              "begincolumn": "31",
              "endcolumn": "58",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Cart",
              "method": "getSubTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\CartItem.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "7",
              "endline": "65",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "7",
              "endline": "65",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "7",
              "endline": "65",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "11",
              "endcolumn": "20",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "11",
              "endcolumn": "23",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "variable": "inStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "22",
              "endcolumn": "26",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "variable": "total",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "variable": "total",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "isInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "34",
              "endcolumn": "40",
              "rule": "AvoidPrefixingMethodParameters",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setInStock",
              "variable": "inStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AvoidPrefixingMethodParameters",
              "priority": "4"
            },
            "_text": "\r\nAvoid prefixing parameters by in, out or inOut. Uses Javadoc to document this behavior.\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "26",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setInStock",
              "variable": "inStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'inStock' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "24",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "28",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "getTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "32",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "23",
              "endcolumn": "31",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'item' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "getQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "43",
              "begincolumn": "27",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setQuantity",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'quantity' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "46",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "setQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "53",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "incrementQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "15",
              "endcolumn": "18",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "class": "CartItem",
              "method": "calculateTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Category.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "8",
              "endline": "57",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "8",
              "endline": "57",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "8",
              "endline": "57",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "11",
              "endcolumn": "29",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "variable": "description",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "11",
              "endcolumn": "42",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "variable": "products",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "getCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setCategoryId",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "25",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "getName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "23",
              "endcolumn": "33",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setName",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'name' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "33",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "getDescription",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "30",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setDescription",
              "variable": "description",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'description' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setDescription",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "45",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "getProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "28",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setProducts",
              "variable": "products",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'products' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "49",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "setProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "55",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Category",
              "method": "toString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Item.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "7",
              "endline": "137",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "ShortClassName",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortClassName",
              "priority": "4"
            },
            "_text": "\r\nAvoid short class names like Item\r\n"
          },
          {
            "_attributes": {
              "beginline": "7",
              "endline": "137",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "7",
              "endline": "137",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "7",
              "endline": "137",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "listPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "11",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "unitCost",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "supplierId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "status",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "attribute1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "attribute2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "attribute3",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "attribute4",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "attribute5",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "product",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "11",
              "endcolumn": "23",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setItemId",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "33",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "27",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setQuantity",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'quantity' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "45",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "26",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setProduct",
              "variable": "product",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'product' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "49",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "51",
              "endline": "53",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getProductId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "55",
              "endline": "55",
              "begincolumn": "28",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setProductId",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "55",
              "endline": "57",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setProductId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "61",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getSupplierId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "63",
              "begincolumn": "29",
              "endcolumn": "42",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setSupplierId",
              "variable": "supplierId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'supplierId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "65",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setSupplierId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "69",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getListPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "71",
              "begincolumn": "28",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setListPrice",
              "variable": "listPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'listPrice' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "73",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setListPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "77",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getUnitCost",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "79",
              "endline": "79",
              "begincolumn": "27",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setUnitCost",
              "variable": "unitCost",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'unitCost' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "79",
              "endline": "81",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setUnitCost",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "85",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getStatus",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "87",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setStatus",
              "variable": "status",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'status' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "89",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setStatus",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "91",
              "endline": "93",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getAttribute1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "95",
              "endline": "95",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute1",
              "variable": "attribute1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'attribute1' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "95",
              "endline": "97",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "99",
              "endline": "101",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getAttribute2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "103",
              "endline": "103",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute2",
              "variable": "attribute2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'attribute2' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "103",
              "endline": "105",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "109",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getAttribute3",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "111",
              "endline": "111",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute3",
              "variable": "attribute3",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'attribute3' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "111",
              "endline": "113",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute3",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "117",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getAttribute4",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "119",
              "endline": "119",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute4",
              "variable": "attribute4",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'attribute4' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "119",
              "endline": "121",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute4",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "125",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "getAttribute5",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "127",
              "endline": "127",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute5",
              "variable": "attribute5",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'attribute5' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "127",
              "endline": "129",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "setAttribute5",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "133",
              "endline": "135",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "toString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "134",
              "endline": "134",
              "begincolumn": "18",
              "endcolumn": "35",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "toString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "134",
              "endline": "134",
              "begincolumn": "45",
              "endcolumn": "65",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Item",
              "method": "toString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\LineItem.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "7",
              "endline": "99",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "7",
              "endline": "99",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "lineNumber",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "11",
              "endcolumn": "23",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "unitPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "11",
              "endcolumn": "20",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "22",
              "endcolumn": "26",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "total",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "variable": "total",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "LineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "35",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "LineItem",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'cartItem' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "19",
              "endcolumn": "32",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "LineItem",
              "variable": "lineNumber",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'lineNumber' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "30",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "LineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "36",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getOrderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "38",
              "begincolumn": "26",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setOrderId",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'orderId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "40",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setOrderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "42",
              "endline": "44",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getLineNumber",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "29",
              "endcolumn": "42",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setLineNumber",
              "variable": "lineNumber",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'lineNumber' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "48",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setLineNumber",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "52",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setItemId",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "56",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "60",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getUnitPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "28",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setUnitPrice",
              "variable": "unitprice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'unitprice' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setUnitPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "68",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "72",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "23",
              "endcolumn": "31",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'item' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "77",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "79",
              "endline": "81",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "getQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "83",
              "begincolumn": "27",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setQuantity",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'quantity' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "86",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "setQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "94",
              "endline": "94",
              "begincolumn": "15",
              "endcolumn": "18",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "class": "LineItem",
              "method": "calculateTotal",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Order.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "1",
              "endline": "314",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "ExcessivePublicCount",
              "ruleset": "Code Size",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#ExcessivePublicCount",
              "priority": "3"
            },
            "_text": "\r\nThis class has a bunch of public methods and attributes\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "314",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "314",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "314",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "TooManyFields",
              "ruleset": "Code Size",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#TooManyFields",
              "priority": "3"
            },
            "_text": "\r\nToo many fields\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "314",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "orderDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "11",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "11",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "11",
              "endcolumn": "29",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "11",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "11",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "11",
              "endcolumn": "29",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "courier",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "11",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "totalPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "11",
              "endcolumn": "33",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "11",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "billToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "11",
              "endcolumn": "33",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "11",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "shipToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "creditCard",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "expiryDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "38",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "cardType",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "locale",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "status",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "11",
              "endcolumn": "43",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "variable": "lineItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "47",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getOrderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "49",
              "endline": "49",
              "begincolumn": "26",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setOrderId",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'orderId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "49",
              "endline": "51",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setOrderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "55",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "57",
              "endline": "57",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setUsername",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "57",
              "endline": "59",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "63",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getOrderDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "65",
              "endline": "65",
              "begincolumn": "28",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setOrderDate",
              "variable": "orderDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'orderDate' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "65",
              "endline": "67",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setOrderDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "69",
              "endline": "71",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "73",
              "begincolumn": "31",
              "endcolumn": "49",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipAddress1",
              "variable": "shipAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipAddress1' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "75",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "77",
              "endline": "79",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "81",
              "begincolumn": "31",
              "endcolumn": "49",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipAddress2",
              "variable": "shipAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipAddress2' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "83",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "85",
              "endline": "87",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "89",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipCity",
              "variable": "shipCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipCity' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "91",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "93",
              "endline": "95",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "97",
              "endline": "97",
              "begincolumn": "28",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipState",
              "variable": "shipState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipState' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "97",
              "endline": "99",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "101",
              "endline": "103",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "105",
              "endline": "105",
              "begincolumn": "26",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipZip",
              "variable": "shipZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipZip' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "105",
              "endline": "107",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "109",
              "endline": "111",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "113",
              "endline": "113",
              "begincolumn": "30",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipCountry",
              "variable": "shipCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipCountry' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "113",
              "endline": "115",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "117",
              "endline": "119",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "121",
              "endline": "121",
              "begincolumn": "31",
              "endcolumn": "49",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillAddress1",
              "variable": "billAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billAddress1' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "121",
              "endline": "123",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillAddress1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "125",
              "endline": "127",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "129",
              "endline": "129",
              "begincolumn": "31",
              "endcolumn": "49",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillAddress2",
              "variable": "billAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billAddress2' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "129",
              "endline": "131",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillAddress2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "133",
              "endline": "135",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "137",
              "endline": "137",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillCity",
              "variable": "billCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billCity' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "137",
              "endline": "139",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillCity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "141",
              "endline": "143",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "145",
              "endline": "145",
              "begincolumn": "28",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillState",
              "variable": "billState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billState' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "145",
              "endline": "147",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillState",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "149",
              "endline": "151",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "153",
              "endline": "153",
              "begincolumn": "26",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillZip",
              "variable": "billZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billZip' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "153",
              "endline": "155",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillZip",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "157",
              "endline": "159",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "161",
              "endline": "161",
              "begincolumn": "30",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillCountry",
              "variable": "billCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billCountry' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "161",
              "endline": "163",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillCountry",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "165",
              "endline": "167",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getCourier",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "169",
              "endline": "169",
              "begincolumn": "26",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setCourier",
              "variable": "courier",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'courier' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "169",
              "endline": "171",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setCourier",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "173",
              "endline": "175",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getTotalPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "177",
              "endline": "177",
              "begincolumn": "29",
              "endcolumn": "49",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setTotalPrice",
              "variable": "totalPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'totalPrice' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "177",
              "endline": "179",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setTotalPrice",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "181",
              "endline": "183",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "185",
              "endline": "185",
              "begincolumn": "34",
              "endcolumn": "55",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillToFirstName",
              "variable": "billToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billToFirstName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "185",
              "endline": "187",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "189",
              "endline": "191",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getBillToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "193",
              "endline": "193",
              "begincolumn": "33",
              "endcolumn": "53",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillToLastName",
              "variable": "billToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'billToLastName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "193",
              "endline": "195",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setBillToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "197",
              "endline": "199",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "201",
              "endline": "201",
              "begincolumn": "34",
              "endcolumn": "55",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipToFirstName",
              "variable": "shipFoFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipFoFirstName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "201",
              "endline": "203",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipToFirstName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "205",
              "endline": "207",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getShipToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "209",
              "endline": "209",
              "begincolumn": "33",
              "endcolumn": "53",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipToLastName",
              "variable": "shipToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shipToLastName' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "209",
              "endline": "211",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setShipToLastName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "213",
              "endline": "215",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getCreditCard",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "217",
              "endline": "217",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setCreditCard",
              "variable": "creditCard",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'creditCard' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "217",
              "endline": "219",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setCreditCard",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "221",
              "endline": "223",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getExpiryDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "225",
              "endline": "225",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setExpiryDate",
              "variable": "expiryDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'expiryDate' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "225",
              "endline": "227",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setExpiryDate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "229",
              "endline": "231",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getCardType",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "233",
              "endline": "233",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setCardType",
              "variable": "cardType",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'cardType' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "233",
              "endline": "235",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setCardType",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "237",
              "endline": "239",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getLocale",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "241",
              "endline": "241",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setLocale",
              "variable": "locale",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'locale' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "241",
              "endline": "243",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setLocale",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "245",
              "endline": "247",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getStatus",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "249",
              "endline": "249",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setStatus",
              "variable": "status",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'status' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "249",
              "endline": "251",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setStatus",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "253",
              "endline": "253",
              "begincolumn": "28",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setLineItems",
              "variable": "lineItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'lineItems' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "253",
              "endline": "255",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "setLineItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "257",
              "endline": "259",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "getLineItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "263",
              "endline": "263",
              "begincolumn": "25",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "initOrder",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'account' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "263",
              "endline": "263",
              "begincolumn": "42",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "initOrder",
              "variable": "cart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'cart' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "263",
              "endline": "302",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "initOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "296",
              "endline": "296",
              "begincolumn": "14",
              "endcolumn": "14",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "initOrder",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "296",
              "endline": "296",
              "begincolumn": "5",
              "endcolumn": "39",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "initOrder",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'i' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "298",
              "endline": "298",
              "begincolumn": "7",
              "endcolumn": "45",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "initOrder",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "304",
              "endline": "304",
              "begincolumn": "27",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "addLineItem",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'cartItem' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "304",
              "endline": "307",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "addLineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "305",
              "endline": "305",
              "begincolumn": "5",
              "endcolumn": "68",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "addLineItem",
              "variable": "lineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'lineItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "309",
              "endline": "309",
              "begincolumn": "27",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "addLineItem",
              "variable": "lineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'lineItem' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "309",
              "endline": "311",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Order",
              "method": "addLineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Product.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "6",
              "endline": "55",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "6",
              "endline": "55",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "6",
              "endline": "55",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "10",
              "endline": "10",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "11",
              "endcolumn": "29",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "variable": "description",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "19",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "getProductId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "28",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setProductId",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "23",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setProductId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "27",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "getCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setCategoryId",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "31",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "35",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "getName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "23",
              "endcolumn": "33",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setName",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'name' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "39",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "43",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "getDescription",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "45",
              "begincolumn": "30",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setDescription",
              "variable": "description",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'description' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "47",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "setDescription",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "51",
              "endline": "53",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Product",
              "method": "toString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\domain\\Sequence.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "5",
              "endline": "40",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "MissingSerialVersionUID",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#MissingSerialVersionUID",
              "priority": "3"
            },
            "_text": "\r\nClasses implementing Serializable should set a serialVersionUID\r\n"
          },
          {
            "_attributes": {
              "beginline": "5",
              "endline": "40",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "9",
              "endline": "9",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "10",
              "endline": "10",
              "begincolumn": "11",
              "endcolumn": "21",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "variable": "nextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "15",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "Sequence",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "19",
              "endcolumn": "29",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "Sequence",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'name' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "32",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "Sequence",
              "variable": "nextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'nextId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "Sequence",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "26",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "getName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "23",
              "endcolumn": "33",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "setName",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'name' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "30",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "setName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "34",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "getNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "25",
              "endcolumn": "34",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "setNextId",
              "variable": "nextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'nextId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "38",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.domain",
              "class": "Sequence",
              "method": "setNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\DaoConfig.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "35",
              "endcolumn": "44",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'daoManager' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "24",
              "endcolumn": "45",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "7",
              "endcolumn": "66",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "variable": "resource",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'resource' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "7",
              "endcolumn": "61",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "variable": "reader",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'reader' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "17",
              "endcolumn": "32",
              "rule": "AvoidThrowingRawExceptionTypes",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidThrowingRawExceptionTypes",
              "priority": "1"
            },
            "_text": "\r\nAvoid throwing raw exception types.\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "32",
              "begincolumn": "17",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence",
              "class": "DaoConfig",
              "method": "getDaomanager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\iface\\AccountDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "10",
              "endcolumn": "45",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "10",
              "endcolumn": "45",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "10",
              "endcolumn": "32",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "getUsernameList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "10",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "getUsernameList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "62",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "62",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "45",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "insertAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "45",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "insertAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "45",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "updateAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "45",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "AccountDao",
              "method": "updateAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\iface\\CategoryDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "10",
              "endcolumn": "32",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "CategoryDao",
              "method": "getCategoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "10",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "CategoryDao",
              "method": "getCategoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "10",
              "endcolumn": "49",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "CategoryDao",
              "method": "getCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "10",
              "endcolumn": "49",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "CategoryDao",
              "method": "getCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "63",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "CategoryDao",
              "method": "getCategoryWithProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "63",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "CategoryDao",
              "method": "getCategoryWithProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\iface\\ItemDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "10",
              "endcolumn": "42",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "10",
              "endcolumn": "42",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "10",
              "endcolumn": "46",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "isItemInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "10",
              "endcolumn": "46",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "isItemInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "62",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "getItemListByProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "62",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "getItemListByProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "37",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ItemDao",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\iface\\OrderDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "1",
              "endcolumn": "22",
              "rule": "UnusedImports",
              "ruleset": "Type Resolution",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#UnusedImports",
              "priority": "4"
            },
            "_text": "\r\nAvoid unused imports such as 'java.util.List'\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "1",
              "endcolumn": "22",
              "rule": "UnusedImports",
              "ruleset": "Import Statements",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/imports.html#UnusedImports",
              "priority": "4"
            },
            "_text": "\r\nAvoid unused imports such as 'java.util.List'\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "10",
              "endcolumn": "60",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "OrderDao",
              "method": "getOrdersByUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "10",
              "endcolumn": "60",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "OrderDao",
              "method": "getOrdersByUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "10",
              "endcolumn": "37",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "OrderDao",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "10",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "OrderDao",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "10",
              "endcolumn": "39",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "OrderDao",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "10",
              "endcolumn": "39",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "OrderDao",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\iface\\ProductDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "10",
              "endcolumn": "67",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ProductDao",
              "method": "getProductListByCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "10",
              "endcolumn": "67",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ProductDao",
              "method": "getProductListByCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "10",
              "endcolumn": "46",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ProductDao",
              "method": "getProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "10",
              "endcolumn": "46",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ProductDao",
              "method": "getProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "10",
              "endcolumn": "58",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ProductDao",
              "method": "searchProductList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "10",
              "endcolumn": "58",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "ProductDao",
              "method": "searchProductList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\iface\\SequenceDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "10",
              "endcolumn": "36",
              "rule": "UnusedModifier",
              "ruleset": "Unused Code",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "SequenceDao",
              "method": "getNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedModifier",
              "priority": "3"
            },
            "_text": "\r\nAvoid modifiers which are implied by the context\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "10",
              "endcolumn": "36",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.iface",
              "class": "SequenceDao",
              "method": "getNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\AccountSqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "27",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "AccountSqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "AccountSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getAccount",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "26",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getUsernameList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "46",
              "endcolumn": "60",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getAccount",
              "variable": "password",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'password' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getAccount",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "33",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "5",
              "endcolumn": "35",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "getAccount",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'account' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "insertAccount",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'account' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "39",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "insertAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "updateAccount",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'account' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "48",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "updateAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "45",
              "begincolumn": "42",
              "endcolumn": "71",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "AccountSqlMapDao",
              "method": "updateAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\BaseSqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "26",
              "endcolumn": "43",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "BaseSqlMapDao",
              "variable": "PAGE_SIZE",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "24",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "BaseSqlMapDao",
              "method": "BaseSqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "17",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "BaseSqlMapDao",
              "method": "BaseSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\CategorySqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "28",
              "endcolumn": "48",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "CategorySqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "CategorySqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "getCategoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "31",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "getCategory",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "26",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "getCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "44",
              "endcolumn": "60",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "getCategoryWithProducts",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "30",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "CategorySqlMapDao",
              "method": "getCategoryWithProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\ItemSqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "24",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "ItemSqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "ItemSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "30",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'order' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "25",
              "endcolumn": "51",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "7",
              "endcolumn": "64",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "variable": "lineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'lineItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "38",
              "endcolumn": "64",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "7",
              "endcolumn": "42",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'itemId' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "23",
              "endcolumn": "42",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "27",
              "endcolumn": "61",
              "rule": "IntegerInstantiation",
              "ruleset": "Migration",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/migrating.html#IntegerInstantiation",
              "priority": "2"
            },
            "_text": "\r\nAvoid instantiating Integer objects. Call Integer.valueOf() instead.\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "27",
              "endcolumn": "61",
              "rule": "AvoidInstantiatingObjectsInLoops",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#AvoidInstantiatingObjectsInLoops",
              "priority": "3"
            },
            "_text": "\r\nAvoid instantiating new objects inside loops\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "7",
              "endcolumn": "61",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "variable": "increment",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'increment' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "39",
              "endcolumn": "60",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "19",
              "endcolumn": "32",
              "rule": "AvoidInstantiatingObjectsInLoops",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#AvoidInstantiatingObjectsInLoops",
              "priority": "3"
            },
            "_text": "\r\nAvoid instantiating new objects inside loops\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "7",
              "endcolumn": "9",
              "rule": "UseConcurrentHashMap",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#UseConcurrentHashMap",
              "priority": "3"
            },
            "_text": "\r\nIf you run in Java5 or newer and have concurrent access, you should use the ConcurrentHashMap implementation\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "7",
              "endcolumn": "32",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "updateQuantity",
              "variable": "param",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'param' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "32",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStock",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "42",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "13",
              "endcolumn": "13",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStock",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "5",
              "endcolumn": "72",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStock",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'i' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "26",
              "endcolumn": "37",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "13",
              "endcolumn": "41",
              "rule": "UselessParentheses",
              "ruleset": "Unnecessary",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unnecessary.html#UselessParentheses",
              "priority": "4"
            },
            "_text": "\r\nUseless parentheses.\r\n"
          },
          {
            "_attributes": {
              "beginline": "44",
              "endline": "44",
              "begincolumn": "34",
              "endcolumn": "46",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStockTG",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "44",
              "endline": "51",
              "begincolumn": "10",
              "endcolumn": "11",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStockTG",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "17",
              "endcolumn": "28",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "isItemInStockTG",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "55",
              "endline": "55",
              "begincolumn": "45",
              "endcolumn": "60",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItemListByProduct",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "55",
              "endline": "57",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItemListByProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "59",
              "begincolumn": "23",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "60",
              "endline": "60",
              "begincolumn": "13",
              "endcolumn": "13",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "60",
              "endline": "60",
              "begincolumn": "5",
              "endcolumn": "72",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'i' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "5",
              "endcolumn": "56",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'item' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "5",
              "endcolumn": "34",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "22",
              "endcolumn": "33",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ItemSqlMapDao",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\OrderSqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "25",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "OrderSqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "OrderSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "44",
              "endcolumn": "58",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrdersByUsername",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrdersByUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "25",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'orderId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "30",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "27",
              "begincolumn": "5",
              "endcolumn": "63",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'order' (lines '25'-'27').\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "30",
              "endcolumn": "49",
              "rule": "IntegerInstantiation",
              "ruleset": "Migration",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/migrating.html#IntegerInstantiation",
              "priority": "2"
            },
            "_text": "\r\nAvoid instantiating Integer objects. Call Integer.valueOf() instead.\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "5",
              "endcolumn": "49",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "variable": "parameterObject",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'parameterObject' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "62",
              "endcolumn": "92",
              "rule": "IntegerInstantiation",
              "ruleset": "Migration",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/migrating.html#IntegerInstantiation",
              "priority": "2"
            },
            "_text": "\r\nAvoid instantiating Integer objects. Call Integer.valueOf() instead.\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "74",
              "endcolumn": "91",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "27",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "insertOrder",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'order' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "25",
              "endcolumn": "51",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "7",
              "endcolumn": "64",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "insertOrder",
              "variable": "lineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'lineItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "38",
              "endcolumn": "64",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "7",
              "endcolumn": "45",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "OrderSqlMapDao",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\ProductSqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "27",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "ProductSqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "ProductSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "49",
              "endcolumn": "65",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "getProductListByCategory",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "25",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "getProductListByCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "29",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "getProduct",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "getProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "42",
              "endcolumn": "56",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "searchProductList",
              "variable": "keywords",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'keywords' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "34",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "searchProductList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "5",
              "endcolumn": "56",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "method": "searchProductList",
              "variable": "parameterObject",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'parameterObject' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "51",
              "begincolumn": "17",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "18",
              "endcolumn": "28",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao$ProductSearch",
              "variable": "keywordList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "13",
              "endcolumn": "47",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao$ProductSearch",
              "variable": "keywordList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "26",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao$ProductSearch",
              "method": "ProductSearch",
              "variable": "keywords",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'keywords' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "46",
              "begincolumn": "12",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao$ProductSearch",
              "method": "ProductSearch",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "42",
              "endline": "42",
              "begincolumn": "7",
              "endcolumn": "74",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao$ProductSearch",
              "method": "ProductSearch",
              "variable": "splitter",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'splitter' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "48",
              "endline": "50",
              "begincolumn": "12",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "ProductSqlMapDao$ProductSearch",
              "method": "getKeywordList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\persistence\\sqlmapdao\\SequenceSqlMapDao.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "15",
              "endline": "15",
              "begincolumn": "28",
              "endcolumn": "48",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "SequenceSqlMapDao",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'daoManager' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "17",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "SequenceSqlMapDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "28",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Too many lines\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "37",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "getNextId",
              "variable": "name",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'name' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "32",
              "begincolumn": "5",
              "endcolumn": "65",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "getNextId",
              "variable": "sequence",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'sequence' (lines '30'-'32').\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "5",
              "endcolumn": "73",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "getNextId",
              "variable": "parameterObject",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'parameterObject' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "49",
              "endcolumn": "68",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "getNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "12",
              "endcolumn": "31",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.persistence.sqlmapdao",
              "class": "SequenceSqlMapDao",
              "method": "getNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\presentation\\AccountBean.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "15",
              "endline": "245",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CyclomaticComplexity",
              "ruleset": "Code Size",
              "package": "com.ibatis.jpetstore.presentation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#CyclomaticComplexity",
              "priority": "3"
            },
            "_text": "\r\nThe class 'AccountBean' has a Cyclomatic Complexity of 2 (Highest = 11).\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "245",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "39",
              "endcolumn": "52",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "accountService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'accountService' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "24",
              "endcolumn": "84",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "accountService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "39",
              "endcolumn": "52",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "catalogService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'catalogService' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "24",
              "endcolumn": "84",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "catalogService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "31",
              "endcolumn": "50",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "VALIDATE_NEW_ACCOUNT",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like VALIDATE_NEW_ACCOUNT\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "24",
              "endcolumn": "59",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "VALIDATE_NEW_ACCOUNT",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "31",
              "endcolumn": "51",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "VALIDATE_EDIT_ACCOUNT",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like VALIDATE_EDIT_ACCOUNT\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "24",
              "endcolumn": "61",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "VALIDATE_EDIT_ACCOUNT",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "24",
              "endcolumn": "42",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "LANGUAGE_LIST",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "24",
              "endcolumn": "42",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "CATEGORY_LIST",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "11",
              "endcolumn": "34",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "repeatedPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "validation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "myList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "19",
              "endcolumn": "31",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "authenticated",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "11",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "authenticated",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "5",
              "endcolumn": "35",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "langList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'langList' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "45",
              "begincolumn": "5",
              "endcolumn": "34",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "variable": "catList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'catList' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "56",
              "endline": "58",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "AccountBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "56",
              "endline": "58",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "AccountBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "66",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setUsername",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "68",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "72",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "27",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setPassword",
              "variable": "password",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'password' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "76",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "80",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getMyList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "82",
              "begincolumn": "25",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setMyList",
              "variable": "myList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'myList' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "84",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setMyList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "88",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getRepeatedPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "90",
              "endline": "90",
              "begincolumn": "35",
              "endcolumn": "57",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setRepeatedPassword",
              "variable": "repeatedPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'repeatedPassword' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "90",
              "endline": "92",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setRepeatedPassword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "94",
              "endline": "96",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "98",
              "endline": "98",
              "begincolumn": "26",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setAccount",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'account' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "98",
              "endline": "100",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "103",
              "endline": "105",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getLanguages",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "109",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getCategories",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "111",
              "endline": "113",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "115",
              "begincolumn": "32",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setPageDirection",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'pageDirection' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "117",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "119",
              "endline": "121",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "getValidation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "123",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setValidation",
              "variable": "validation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'validation' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "125",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "setValidation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "129",
              "endline": "140",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "newAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "135",
              "endline": "135",
              "begincolumn": "26",
              "endcolumn": "29",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "newAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "136",
              "endline": "136",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidDuplicateLiterals",
              "ruleset": "String and StringBuffer",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "newAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strings.html#AvoidDuplicateLiterals",
              "priority": "3"
            },
            "_text": "\r\nThe String literal \"success\" appears 6 times in this file; the first occurrence is on line 136\r\n"
          },
          {
            "_attributes": {
              "beginline": "137",
              "endline": "137",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "newAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "142",
              "endline": "149",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "editAccountForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "146",
              "endline": "146",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "editAccountForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "151",
              "endline": "160",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "editAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "157",
              "endline": "157",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "editAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "162",
              "endline": "169",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "switchMyListPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "171",
              "endline": "188",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signon",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "176",
              "endline": "176",
              "begincolumn": "7",
              "endcolumn": "104",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signon",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "178",
              "endline": "178",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signon",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "190",
              "endline": "194",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signoff",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "191",
              "endline": "191",
              "begincolumn": "5",
              "endcolumn": "75",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signoff",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "191",
              "endline": "191",
              "begincolumn": "5",
              "endcolumn": "75",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signoff",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "191",
              "endline": "191",
              "begincolumn": "5",
              "endcolumn": "75",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "signoff",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "196",
              "endline": "198",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "isAuthenticated",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "200",
              "endline": "205",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "reset",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "207",
              "endline": "213",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "209",
              "endline": "209",
              "begincolumn": "24",
              "endcolumn": "27",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "210",
              "endline": "210",
              "begincolumn": "21",
              "endcolumn": "24",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "211",
              "endline": "211",
              "begincolumn": "14",
              "endcolumn": "17",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "215",
              "endline": "243",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CyclomaticComplexity",
              "ruleset": "Code Size",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#CyclomaticComplexity",
              "priority": "3"
            },
            "_text": "\r\nThe method 'validate' has a Cyclomatic Complexity of 11.\r\n"
          },
          {
            "_attributes": {
              "beginline": "215",
              "endline": "243",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "216",
              "endline": "243",
              "begincolumn": "19",
              "endcolumn": "56",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "variable": "ctx",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'ctx' (lines '216'-'243').\r\n"
          },
          {
            "_attributes": {
              "beginline": "216",
              "endline": "216",
              "begincolumn": "5",
              "endcolumn": "56",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "variable": "ctx",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'ctx' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "218",
              "endline": "240",
              "begincolumn": "7",
              "endcolumn": "7",
              "rule": "CollapsibleIfStatements",
              "ruleset": "Basic",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/basic.html#CollapsibleIfStatements",
              "priority": "3"
            },
            "_text": "\r\nThese nested if statements could be combined\r\n"
          },
          {
            "_attributes": {
              "beginline": "222",
              "endline": "222",
              "begincolumn": "48",
              "endcolumn": "77",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "222",
              "endline": "222",
              "begincolumn": "87",
              "endcolumn": "132",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "223",
              "endline": "223",
              "begincolumn": "13",
              "endcolumn": "113",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "226",
              "endline": "226",
              "begincolumn": "46",
              "endcolumn": "75",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "227",
              "endline": "227",
              "begincolumn": "16",
              "endcolumn": "61",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "227",
              "endline": "229",
              "begincolumn": "11",
              "endcolumn": "11",
              "rule": "CollapsibleIfStatements",
              "ruleset": "Basic",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/basic.html#CollapsibleIfStatements",
              "priority": "3"
            },
            "_text": "\r\nThese nested if statements could be combined\r\n"
          },
          {
            "_attributes": {
              "beginline": "228",
              "endline": "228",
              "begincolumn": "13",
              "endcolumn": "58",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "AccountBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\presentation\\CartBean.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "13",
              "endline": "120",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "120",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "39",
              "endcolumn": "52",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "variable": "catalogService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'catalogService' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "24",
              "endcolumn": "84",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "variable": "catalogService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "11",
              "endcolumn": "33",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "variable": "cart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "variable": "workingItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "getCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "23",
              "endcolumn": "31",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "setCart",
              "variable": "cart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'cart' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "33",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "setCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "getWorkingItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "32",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "setWorkingItemId",
              "variable": "workingItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'workingItemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "setWorkingItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "45",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "getPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "32",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "setPageDirection",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'pageDirection' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "49",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "setPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "66",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "addItemToCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "60",
              "endline": "60",
              "begincolumn": "7",
              "endcolumn": "69",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "addItemToCart",
              "variable": "isInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'isInStock' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "7",
              "endcolumn": "55",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "addItemToCart",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'item' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "65",
              "endline": "65",
              "begincolumn": "12",
              "endcolumn": "20",
              "rule": "AvoidDuplicateLiterals",
              "ruleset": "String and StringBuffer",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "addItemToCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strings.html#AvoidDuplicateLiterals",
              "priority": "3"
            },
            "_text": "\r\nThe String literal \"success\" appears 5 times in this file; the first occurrence is on line 65\r\n"
          },
          {
            "_attributes": {
              "beginline": "68",
              "endline": "78",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "removeItemFromCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "70",
              "begincolumn": "5",
              "endcolumn": "50",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "removeItemFromCart",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'item' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "73",
              "begincolumn": "7",
              "endcolumn": "103",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "removeItemFromCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "removeItemFromCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "80",
              "endline": "99",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "99",
              "begincolumn": "9",
              "endcolumn": "73",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "variable": "parameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'parameterMap' (lines '81'-'99').\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "81",
              "begincolumn": "5",
              "endcolumn": "73",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "variable": "parameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'parameterMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "81",
              "begincolumn": "24",
              "endcolumn": "73",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "83",
              "begincolumn": "5",
              "endcolumn": "52",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "variable": "cartItems",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItems' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "83",
              "begincolumn": "26",
              "endcolumn": "52",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "85",
              "endline": "85",
              "begincolumn": "7",
              "endcolumn": "53",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "variable": "cartItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "7",
              "endcolumn": "52",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'itemId' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "23",
              "endcolumn": "52",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "23",
              "endcolumn": "52",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "88",
              "endline": "88",
              "begincolumn": "9",
              "endcolumn": "74",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "variable": "quantity",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'quantity' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "88",
              "endline": "88",
              "begincolumn": "50",
              "endcolumn": "73",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "89",
              "begincolumn": "9",
              "endcolumn": "55",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "90",
              "endline": "90",
              "begincolumn": "24",
              "endcolumn": "24",
              "rule": "AvoidLiteralsInIfCondition",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AvoidLiteralsInIfCondition",
              "priority": "3"
            },
            "_text": "\r\nAvoid using Literals in Conditional Statements\r\n"
          },
          {
            "_attributes": {
              "beginline": "93",
              "endline": "93",
              "begincolumn": "16",
              "endcolumn": "24",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "93",
              "endline": "95",
              "begincolumn": "9",
              "endcolumn": "7",
              "rule": "EmptyCatchBlock",
              "ruleset": "Empty Code",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "updateCartQuantities",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/empty.html#EmptyCatchBlock",
              "priority": "3"
            },
            "_text": "\r\nAvoid empty catch blocks\r\n"
          },
          {
            "_attributes": {
              "beginline": "101",
              "endline": "108",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "switchCartPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "103",
              "endline": "103",
              "begincolumn": "7",
              "endcolumn": "39",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "switchCartPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "105",
              "endline": "105",
              "begincolumn": "7",
              "endcolumn": "43",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "switchCartPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "110",
              "endline": "112",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "viewCart",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "114",
              "endline": "118",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "116",
              "endline": "116",
              "begincolumn": "21",
              "endcolumn": "24",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "117",
              "endline": "117",
              "begincolumn": "21",
              "endcolumn": "24",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CartBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\presentation\\CatalogBean.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "17",
              "endline": "199",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "39",
              "endcolumn": "52",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "catalogService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'catalogService' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "24",
              "endcolumn": "84",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "catalogService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "keyword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "category",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "categoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "product",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "11",
              "endcolumn": "36",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "productList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "11",
              "endcolumn": "20",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "38",
              "begincolumn": "11",
              "endcolumn": "33",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "variable": "itemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "42",
              "endline": "44",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getKeyword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "26",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setKeyword",
              "variable": "keyword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'keyword' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "48",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setKeyword",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "52",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "32",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setPageDirection",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'pageDirection' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "56",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "60",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "29",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setCategoryId",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setCategoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "68",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getProductId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "70",
              "begincolumn": "28",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setProductId",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "72",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setProductId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "76",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "78",
              "begincolumn": "25",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setItemId",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "80",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setItemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "84",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "27",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setCategory",
              "variable": "category",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'category' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "88",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "90",
              "endline": "92",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "94",
              "endline": "94",
              "begincolumn": "26",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setProduct",
              "variable": "product",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'product' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "94",
              "endline": "96",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "98",
              "endline": "100",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "102",
              "endline": "102",
              "begincolumn": "23",
              "endcolumn": "31",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setItem",
              "variable": "item",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'item' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "102",
              "endline": "104",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "108",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getCategoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "110",
              "endline": "110",
              "begincolumn": "31",
              "endcolumn": "56",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setCategoryList",
              "variable": "categoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryList' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "110",
              "endline": "112",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setCategoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "114",
              "endline": "116",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getProductList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "118",
              "endline": "118",
              "begincolumn": "30",
              "endcolumn": "54",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setProductList",
              "variable": "productList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productList' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "118",
              "endline": "120",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setProductList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "122",
              "endline": "124",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "getItemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "126",
              "endline": "126",
              "begincolumn": "27",
              "endcolumn": "48",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setItemList",
              "variable": "itemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemList' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "126",
              "endline": "128",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "setItemList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "132",
              "endline": "138",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "viewCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "137",
              "endline": "137",
              "begincolumn": "12",
              "endcolumn": "20",
              "rule": "AvoidDuplicateLiterals",
              "ruleset": "String and StringBuffer",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "viewCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strings.html#AvoidDuplicateLiterals",
              "priority": "3"
            },
            "_text": "\r\nThe String literal \"success\" appears 6 times in this file; the first occurrence is on line 137\r\n"
          },
          {
            "_attributes": {
              "beginline": "140",
              "endline": "148",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "searchProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "142",
              "endline": "142",
              "begincolumn": "7",
              "endcolumn": "126",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "searchProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "143",
              "endline": "143",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "searchProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "150",
              "endline": "157",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "switchProductListPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "159",
              "endline": "165",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "viewProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "167",
              "endline": "174",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "switchItemListPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "176",
              "endline": "180",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "viewItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "182",
              "endline": "197",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "183",
              "endline": "183",
              "begincolumn": "15",
              "endcolumn": "18",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "184",
              "endline": "184",
              "begincolumn": "21",
              "endcolumn": "24",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "186",
              "endline": "186",
              "begincolumn": "18",
              "endcolumn": "21",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "187",
              "endline": "187",
              "begincolumn": "16",
              "endcolumn": "19",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "188",
              "endline": "188",
              "begincolumn": "20",
              "endcolumn": "23",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "190",
              "endline": "190",
              "begincolumn": "17",
              "endcolumn": "20",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "191",
              "endline": "191",
              "begincolumn": "15",
              "endcolumn": "18",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "192",
              "endline": "192",
              "begincolumn": "19",
              "endcolumn": "22",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "194",
              "endline": "194",
              "begincolumn": "14",
              "endcolumn": "17",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "195",
              "endline": "195",
              "begincolumn": "12",
              "endcolumn": "15",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "196",
              "endline": "196",
              "begincolumn": "16",
              "endcolumn": "19",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "CatalogBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\presentation\\OrderBean.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "16",
              "endline": "231",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "39",
              "endcolumn": "52",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "accountService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'accountService' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "24",
              "endcolumn": "84",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "accountService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "37",
              "endcolumn": "48",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "orderService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'orderService' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "24",
              "endcolumn": "78",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "orderService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "24",
              "endcolumn": "43",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "CARD_TYPE_LIST",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "11",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "19",
              "endcolumn": "41",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "shippingAddressRequired",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like shippingAddressRequired\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "11",
              "endcolumn": "42",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "shippingAddressRequired",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "confirmed",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "25",
              "endcolumn": "33",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "orderList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "11",
              "endcolumn": "34",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "orderList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "11",
              "endcolumn": "31",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "5",
              "endcolumn": "35",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "variable": "cardList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cardList' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "50",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "OrderBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "50",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "OrderBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "56",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "getOrderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "58",
              "begincolumn": "26",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setOrderId",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'orderId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "60",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setOrderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "66",
              "begincolumn": "24",
              "endcolumn": "34",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setOrder",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'order' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "68",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "72",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "isShippingAddressRequired",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "50",
              "endcolumn": "72",
              "rule": "LongVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setShippingAddressRequired",
              "variable": "shippingAddressRequired",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#LongVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid excessively long variable names like shippingAddressRequired\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "42",
              "endcolumn": "72",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setShippingAddressRequired",
              "variable": "shippingAddressRequired",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'shippingAddressRequired' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "76",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setShippingAddressRequired",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "80",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "isConfirmed",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "82",
              "begincolumn": "28",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setConfirmed",
              "variable": "confirmed",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'confirmed' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "84",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setConfirmed",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "88",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "getCreditCardTypes",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "90",
              "endline": "92",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "getOrderList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "94",
              "endline": "96",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "getPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "98",
              "endline": "98",
              "begincolumn": "32",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setPageDirection",
              "variable": "pageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'pageDirection' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "98",
              "endline": "100",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "setPageDirection",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "104",
              "endline": "122",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "105",
              "endline": "105",
              "begincolumn": "5",
              "endcolumn": "69",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'sessionMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "105",
              "endline": "105",
              "begincolumn": "22",
              "endcolumn": "69",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "106",
              "begincolumn": "5",
              "endcolumn": "73",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "variable": "accountBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'accountBean' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "106",
              "begincolumn": "45",
              "endcolumn": "73",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "122",
              "begincolumn": "14",
              "endcolumn": "61",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "variable": "cartBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'cartBean' (lines '107'-'122').\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "107",
              "begincolumn": "5",
              "endcolumn": "61",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "variable": "cartBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartBean' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "107",
              "begincolumn": "36",
              "endcolumn": "61",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "110",
              "endline": "110",
              "begincolumn": "33",
              "endcolumn": "61",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "111",
              "endline": "111",
              "begincolumn": "7",
              "endcolumn": "151",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "112",
              "endline": "112",
              "begincolumn": "7",
              "endcolumn": "22",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "115",
              "begincolumn": "7",
              "endcolumn": "89",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'account' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "115",
              "begincolumn": "25",
              "endcolumn": "89",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "115",
              "begincolumn": "51",
              "endcolumn": "88",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "115",
              "endline": "115",
              "begincolumn": "51",
              "endcolumn": "88",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "116",
              "endline": "116",
              "begincolumn": "32",
              "endcolumn": "49",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "117",
              "endline": "117",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "117",
              "endline": "117",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidDuplicateLiterals",
              "ruleset": "String and StringBuffer",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strings.html#AvoidDuplicateLiterals",
              "priority": "3"
            },
            "_text": "\r\nThe String literal \"success\" appears 5 times in this file; the first occurrence is on line 117\r\n"
          },
          {
            "_attributes": {
              "beginline": "119",
              "endline": "119",
              "begincolumn": "7",
              "endcolumn": "123",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrderForm",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "124",
              "endline": "146",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "125",
              "endline": "146",
              "begincolumn": "9",
              "endcolumn": "69",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'sessionMap' (lines '125'-'146').\r\n"
          },
          {
            "_attributes": {
              "beginline": "125",
              "endline": "125",
              "begincolumn": "5",
              "endcolumn": "69",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'sessionMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "125",
              "endline": "125",
              "begincolumn": "22",
              "endcolumn": "69",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "129",
              "endline": "129",
              "begincolumn": "7",
              "endcolumn": "24",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "131",
              "endline": "131",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "136",
              "endline": "136",
              "begincolumn": "7",
              "endcolumn": "62",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "variable": "cartBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'cartBean' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "136",
              "endline": "136",
              "begincolumn": "37",
              "endcolumn": "62",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "137",
              "endline": "137",
              "begincolumn": "7",
              "endcolumn": "22",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "139",
              "endline": "139",
              "begincolumn": "7",
              "endcolumn": "100",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "141",
              "endline": "141",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "143",
              "endline": "143",
              "begincolumn": "7",
              "endcolumn": "116",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "newOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "148",
              "endline": "153",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "149",
              "endline": "149",
              "begincolumn": "5",
              "endcolumn": "69",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'sessionMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "149",
              "endline": "149",
              "begincolumn": "22",
              "endcolumn": "69",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "150",
              "endline": "150",
              "begincolumn": "5",
              "endcolumn": "73",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "variable": "accountBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'accountBean' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "150",
              "endline": "150",
              "begincolumn": "45",
              "endcolumn": "73",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "151",
              "endline": "151",
              "begincolumn": "17",
              "endcolumn": "88",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "151",
              "endline": "151",
              "begincolumn": "50",
              "endcolumn": "87",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "151",
              "endline": "151",
              "begincolumn": "50",
              "endcolumn": "87",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "listOrders",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "155",
              "endline": "162",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "switchOrderPage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "165",
              "endline": "178",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "166",
              "endline": "166",
              "begincolumn": "5",
              "endcolumn": "69",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'sessionMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "166",
              "endline": "166",
              "begincolumn": "22",
              "endcolumn": "69",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "167",
              "endline": "167",
              "begincolumn": "5",
              "endcolumn": "73",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "variable": "accountBean",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'accountBean' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "167",
              "endline": "167",
              "begincolumn": "45",
              "endcolumn": "73",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "171",
              "endline": "171",
              "begincolumn": "9",
              "endcolumn": "74",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "171",
              "endline": "171",
              "begincolumn": "9",
              "endcolumn": "74",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "171",
              "endline": "171",
              "begincolumn": "9",
              "endcolumn": "74",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "172",
              "endline": "172",
              "begincolumn": "7",
              "endcolumn": "23",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "174",
              "endline": "174",
              "begincolumn": "15",
              "endcolumn": "18",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "175",
              "endline": "175",
              "begincolumn": "7",
              "endcolumn": "93",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "viewOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "180",
              "endline": "182",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "reset",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "184",
              "endline": "191",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "189",
              "endline": "189",
              "begincolumn": "17",
              "endcolumn": "20",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "190",
              "endline": "190",
              "begincolumn": "21",
              "endcolumn": "24",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "193",
              "endline": "229",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "194",
              "endline": "194",
              "begincolumn": "5",
              "endcolumn": "56",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "validate",
              "variable": "ctx",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'ctx' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "218",
              "endline": "218",
              "begincolumn": "9",
              "endcolumn": "33",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.presentation",
              "class": "OrderBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\service\\AccountService.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "39",
              "endcolumn": "46",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "instance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'instance' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "24",
              "endcolumn": "70",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "instance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "22",
              "endcolumn": "31",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "11",
              "endcolumn": "60",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "17",
              "endcolumn": "26",
              "rule": "RedundantFieldInitializer",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "xyz",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#RedundantFieldInitializer",
              "priority": "3"
            },
            "_text": "\r\nAvoid using redundant field initializer for 'xyz'\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "10",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "xyz",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "14",
              "endcolumn": "18",
              "rule": "RedundantFieldInitializer",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#RedundantFieldInitializer",
              "priority": "3"
            },
            "_text": "\r\nAvoid using redundant field initializer for 'i'\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "14",
              "endcolumn": "14",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "10",
              "endcolumn": "19",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "18",
              "endcolumn": "29",
              "rule": "RedundantFieldInitializer",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "flag",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#RedundantFieldInitializer",
              "priority": "3"
            },
            "_text": "\r\nAvoid using redundant field initializer for 'flag'\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "10",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "flag",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "22",
              "endcolumn": "31",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "accountDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "11",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "variable": "accountDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "40",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "AccountService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "44",
              "endline": "46",
              "begincolumn": "17",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getInstance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getAccount",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "52",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "46",
              "endcolumn": "60",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getAccount",
              "variable": "password",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'password' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getAccount",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "56",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "58",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "insertAccount",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'account' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "60",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "insertAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "29",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "updateAccount",
              "variable": "account",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'account' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "updateAccount",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "68",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "AccountService",
              "method": "getUsernameList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\service\\CatalogService.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "15",
              "endline": "85",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "39",
              "endcolumn": "46",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "instance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'instance' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "24",
              "endcolumn": "70",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "instance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "22",
              "endcolumn": "31",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "11",
              "endcolumn": "60",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "23",
              "endcolumn": "33",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "categoryDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "11",
              "endcolumn": "34",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "categoryDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "19",
              "endcolumn": "25",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "itemDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "itemDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "22",
              "endcolumn": "31",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "productDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "11",
              "endcolumn": "32",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "variable": "productDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "17",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getInstance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "47",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getCategoryList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "49",
              "endline": "49",
              "begincolumn": "31",
              "endcolumn": "47",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getCategory",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "49",
              "endline": "51",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "53",
              "begincolumn": "43",
              "endcolumn": "59",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getCategoryWithProducts",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "55",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getCategoryWithProducts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "59",
              "begincolumn": "29",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getProduct",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "59",
              "endline": "61",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "63",
              "begincolumn": "49",
              "endcolumn": "65",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getProductListByCategory",
              "variable": "categoryId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'categoryId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "65",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getProductListByCategory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "67",
              "begincolumn": "42",
              "endcolumn": "56",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "searchProductList",
              "variable": "keywords",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'keywords' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "69",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "searchProductList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "73",
              "begincolumn": "45",
              "endcolumn": "60",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getItemListByProduct",
              "variable": "productId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'productId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "75",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getItemListByProduct",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "77",
              "endline": "77",
              "begincolumn": "23",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getItem",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "77",
              "endline": "79",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "getItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "81",
              "begincolumn": "32",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "isItemInStock",
              "variable": "itemId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'itemId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "83",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "CatalogService",
              "method": "isItemInStock",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\jpetstore\\service\\OrderService.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "1",
              "endcolumn": "22",
              "rule": "UnusedImports",
              "ruleset": "Type Resolution",
              "package": "com.ibatis.jpetstore.service",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#UnusedImports",
              "priority": "4"
            },
            "_text": "\r\nAvoid unused imports such as 'java.util.List'\r\n"
          },
          {
            "_attributes": {
              "beginline": "12",
              "endline": "12",
              "begincolumn": "1",
              "endcolumn": "22",
              "rule": "UnusedImports",
              "ruleset": "Import Statements",
              "package": "com.ibatis.jpetstore.service",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/imports.html#UnusedImports",
              "priority": "4"
            },
            "_text": "\r\nAvoid unused imports such as 'java.util.List'\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "37",
              "endcolumn": "44",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "instance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'instance' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "24",
              "endcolumn": "66",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "instance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "22",
              "endcolumn": "31",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "11",
              "endcolumn": "60",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "daoManager",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "19",
              "endcolumn": "25",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "itemDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "26",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "itemDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "20",
              "endcolumn": "27",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "orderDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "11",
              "endcolumn": "28",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "orderDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "23",
              "endcolumn": "33",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "sequenceDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "11",
              "endcolumn": "34",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "variable": "sequenceDao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "40",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "OrderService",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "44",
              "endline": "46",
              "begincolumn": "17",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getInstance",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "27",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "insertOrder",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'order' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "64",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "insertOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "66",
              "begincolumn": "25",
              "endcolumn": "35",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "variable": "orderId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'orderId' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "66",
              "endline": "85",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "72",
              "begincolumn": "7",
              "endcolumn": "40",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "variable": "order",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'order' (lines '67'-'72').\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "27",
              "endcolumn": "53",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "74",
              "endline": "74",
              "begincolumn": "27",
              "endcolumn": "53",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "75",
              "begincolumn": "9",
              "endcolumn": "66",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "variable": "lineItem",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'lineItem' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "75",
              "begincolumn": "40",
              "endcolumn": "66",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "75",
              "begincolumn": "40",
              "endcolumn": "66",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "76",
              "endline": "76",
              "begincolumn": "9",
              "endcolumn": "63",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "76",
              "endline": "76",
              "begincolumn": "42",
              "endcolumn": "61",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "87",
              "begincolumn": "44",
              "endcolumn": "58",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrdersByUsername",
              "variable": "username",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'username' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "89",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getOrdersByUsername",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "93",
              "endline": "93",
              "begincolumn": "37",
              "endcolumn": "46",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getNextId",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "93",
              "endline": "95",
              "begincolumn": "23",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.jpetstore.service",
              "class": "OrderService",
              "method": "getNextId",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\ActionContext.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "3",
              "endline": "3",
              "begincolumn": "1",
              "endcolumn": "35",
              "rule": "UnusedImports",
              "ruleset": "Type Resolution",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#UnusedImports",
              "priority": "4"
            },
            "_text": "\r\nAvoid unused imports such as 'com.ibatis.struts.httpmap'\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "29",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Too many lines\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "36",
              "endcolumn": "47",
              "rule": "VariableNamingConventions",
              "ruleset": "Naming",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "localContext",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#VariableNamingConventions",
              "priority": "1"
            },
            "_text": "\r\nVariables that are final and static should be all capitals, 'localContext' is not all capitals.\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "24",
              "endcolumn": "68",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "localContext",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "30",
              "endcolumn": "36",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "11",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "31",
              "endcolumn": "38",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "response",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "11",
              "endcolumn": "39",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "response",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "15",
              "endcolumn": "23",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "cookieMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "11",
              "endcolumn": "24",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "cookieMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "38",
              "begincolumn": "15",
              "endcolumn": "26",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "parameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "38",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "parameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "15",
              "endcolumn": "24",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "requestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "requestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "15",
              "endcolumn": "24",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "11",
              "endcolumn": "25",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "sessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "15",
              "endcolumn": "28",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "applicationMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "11",
              "endcolumn": "29",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "variable": "applicationMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "36",
              "endcolumn": "61",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "64",
              "endcolumn": "91",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "variable": "response",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'response' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "55",
              "begincolumn": "20",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "5",
              "endcolumn": "42",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "variable": "ctx",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'ctx' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "21",
              "endcolumn": "24",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "51",
              "endline": "51",
              "begincolumn": "24",
              "endcolumn": "27",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "52",
              "endline": "52",
              "begincolumn": "22",
              "endcolumn": "25",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "53",
              "begincolumn": "22",
              "endcolumn": "25",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "26",
              "endcolumn": "29",
              "rule": "NullAssignment",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "initialize",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#NullAssignment",
              "priority": "3"
            },
            "_text": "\r\nAssigning an Object to null is a code smell.  Consider refactoring.\r\n"
          },
          {
            "_attributes": {
              "beginline": "57",
              "endline": "57",
              "begincolumn": "32",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "setSimpleMessage",
              "variable": "message",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'message' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "57",
              "endline": "59",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "setSimpleMessage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "58",
              "begincolumn": "5",
              "endcolumn": "43",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "setSimpleMessage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "30",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "addSimpleError",
              "variable": "message",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'message' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "68",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "addSimpleError",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "26",
              "endcolumn": "54",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "addSimpleError",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "65",
              "endline": "65",
              "begincolumn": "7",
              "endcolumn": "43",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "addSimpleError",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "73",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "isSimpleErrorsExist",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "71",
              "begincolumn": "5",
              "endcolumn": "54",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "isSimpleErrorsExist",
              "variable": "errors",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'errors' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "71",
              "begincolumn": "26",
              "endcolumn": "54",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "isSimpleErrorsExist",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "72",
              "endline": "72",
              "begincolumn": "30",
              "endcolumn": "42",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "isSimpleErrorsExist",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "80",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getCookieMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "82",
              "endline": "87",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getParameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "94",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getRequestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "96",
              "endline": "101",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getSessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "103",
              "endline": "108",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getApplicationMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "110",
              "endline": "112",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getRequest",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "114",
              "endline": "116",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getResponse",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "118",
              "endline": "125",
              "begincolumn": "17",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "ActionContext",
              "method": "getActionContext",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\BaseBean.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "13",
              "endline": "28",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Too many lines\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "90",
              "begincolumn": "17",
              "endcolumn": "1",
              "rule": "AbstractNaming",
              "ruleset": "Naming",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#AbstractNaming",
              "priority": "3"
            },
            "_text": "\r\nAbstract classes should be named AbstractXXX\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "90",
              "begincolumn": "17",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "21",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "variable": "mapping",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'mapping' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "44",
              "endcolumn": "65",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "34",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "21",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "variable": "mapping",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'mapping' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "44",
              "endcolumn": "69",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "39",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "32",
              "endcolumn": "52",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "mapping",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'mapping' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "55",
              "endcolumn": "76",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "56",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "43",
              "begincolumn": "5",
              "endcolumn": "56",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "ctx",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'ctx' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "44",
              "endline": "44",
              "begincolumn": "5",
              "endcolumn": "40",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "requestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'requestMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "47",
              "endline": "47",
              "begincolumn": "20",
              "endcolumn": "27",
              "rule": "AvoidDuplicateLiterals",
              "ruleset": "String and StringBuffer",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strings.html#AvoidDuplicateLiterals",
              "priority": "3"
            },
            "_text": "\r\nThe String literal \"errors\" appears 4 times in this file; the first occurrence is on line 47\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "52",
              "begincolumn": "7",
              "endcolumn": "39",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "actionErrors",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'actionErrors' (lines '50'-'52').\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "58",
              "begincolumn": "32",
              "endcolumn": "52",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "mapping",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'mapping' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "58",
              "begincolumn": "55",
              "endcolumn": "80",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "73",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "60",
              "endline": "60",
              "begincolumn": "5",
              "endcolumn": "56",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "ctx",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'ctx' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "5",
              "endcolumn": "40",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "requestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'requestMap' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "67",
              "endline": "69",
              "begincolumn": "7",
              "endcolumn": "39",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "variable": "actionErrors",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'actionErrors' (lines '67'-'69').\r\n"
          },
          {
            "_attributes": {
              "beginline": "75",
              "endline": "76",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "79",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "reset",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "81",
              "endline": "82",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "84",
              "endline": "84",
              "begincolumn": "54",
              "endcolumn": "72",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validateRequiredField",
              "variable": "errorMessage",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'errorMessage' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "84",
              "endline": "84",
              "begincolumn": "40",
              "endcolumn": "51",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validateRequiredField",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "84",
              "endline": "88",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validateRequiredField",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "85",
              "endline": "85",
              "begincolumn": "26",
              "endcolumn": "46",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validateRequiredField",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "86",
              "endline": "86",
              "begincolumn": "7",
              "endcolumn": "67",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BaseBean",
              "method": "validateRequiredField",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\BeanAction.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "12",
              "endline": "103",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Too many lines\r\n"
          },
          {
            "_attributes": {
              "beginline": "79",
              "endline": "79",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "93",
              "endline": "93",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "96",
              "endline": "96",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "104",
              "endline": "155",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "104",
              "endline": "155",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CyclomaticComplexity",
              "ruleset": "Code Size",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#CyclomaticComplexity",
              "priority": "3"
            },
            "_text": "\r\nThe class 'BeanAction' has a Cyclomatic Complexity of 12 (Highest = 11).\r\n"
          },
          {
            "_attributes": {
              "beginline": "104",
              "endline": "155",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "ModifiedCyclomaticComplexity",
              "ruleset": "Code Size",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#ModifiedCyclomaticComplexity",
              "priority": "3"
            },
            "_text": "\r\nThe class 'BeanAction' has a Modified Cyclomatic Complexity of 10 (Highest = 9).\r\n"
          },
          {
            "_attributes": {
              "beginline": "104",
              "endline": "155",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "StdCyclomaticComplexity",
              "ruleset": "Code Size",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#StdCyclomaticComplexity",
              "priority": "3"
            },
            "_text": "\r\nThe class 'BeanAction' has a Standard Cyclomatic Complexity of 10 (Highest = 9).\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "106",
              "begincolumn": "55",
              "endcolumn": "69",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "form",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'form' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "106",
              "begincolumn": "32",
              "endcolumn": "52",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "mapping",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'mapping' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "106",
              "begincolumn": "72",
              "endcolumn": "97",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "106",
              "begincolumn": "100",
              "endcolumn": "127",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "response",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'response' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "153",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CyclomaticComplexity",
              "ruleset": "Code Size",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#CyclomaticComplexity",
              "priority": "3"
            },
            "_text": "\r\nThe method 'execute' has a Cyclomatic Complexity of 11.\r\n"
          },
          {
            "_attributes": {
              "beginline": "106",
              "endline": "153",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "107",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "SignatureDeclareThrowsException",
              "ruleset": "Type Resolution",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#SignatureDeclareThrowsException",
              "priority": "3"
            },
            "_text": "\r\nA method/constructor shouldnt explicitly throw java.lang.Exception\r\n"
          },
          {
            "_attributes": {
              "beginline": "107",
              "endline": "107",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "SignatureDeclareThrowsException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#SignatureDeclareThrowsException",
              "priority": "3"
            },
            "_text": "\r\nA method/constructor shouldnt explicitly throw java.lang.Exception\r\n"
          },
          {
            "_attributes": {
              "beginline": "109",
              "endline": "123",
              "begincolumn": "13",
              "endcolumn": "56",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "forward",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'forward' (lines '109'-'123').\r\n"
          },
          {
            "_attributes": {
              "beginline": "109",
              "endline": "138",
              "begincolumn": "17",
              "endcolumn": "60",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "forward",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'forward' (lines '109'-'138').\r\n"
          },
          {
            "_attributes": {
              "beginline": "109",
              "endline": "153",
              "begincolumn": "12",
              "endcolumn": "30",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "forward",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'forward' (lines '109'-'153').\r\n"
          },
          {
            "_attributes": {
              "beginline": "118",
              "endline": "122",
              "begincolumn": "13",
              "endcolumn": "64",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "method",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'method' (lines '118'-'122').\r\n"
          },
          {
            "_attributes": {
              "beginline": "122",
              "endline": "122",
              "begincolumn": "22",
              "endcolumn": "64",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "153",
              "begincolumn": "13",
              "endcolumn": "56",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "forward",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'forward' (lines '123'-'153').\r\n"
          },
          {
            "_attributes": {
              "beginline": "123",
              "endline": "123",
              "begincolumn": "32",
              "endcolumn": "56",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "124",
              "endline": "124",
              "begincolumn": "20",
              "endcolumn": "28",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "132",
              "endline": "132",
              "begincolumn": "37",
              "endcolumn": "37",
              "rule": "AvoidLiteralsInIfCondition",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AvoidLiteralsInIfCondition",
              "priority": "3"
            },
            "_text": "\r\nAvoid using Literals in Conditional Statements\r\n"
          },
          {
            "_attributes": {
              "beginline": "132",
              "endline": "132",
              "begincolumn": "15",
              "endcolumn": "33",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "133",
              "endline": "133",
              "begincolumn": "13",
              "endcolumn": "55",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "slash",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'slash' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "133",
              "endline": "133",
              "begincolumn": "25",
              "endcolumn": "51",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "133",
              "endline": "133",
              "begincolumn": "25",
              "endcolumn": "46",
              "rule": "UseIndexOfChar",
              "ruleset": "String and StringBuffer",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strings.html#UseIndexOfChar",
              "priority": "3"
            },
            "_text": "\r\nString.indexOf(char) is faster than String.indexOf(String).\r\n"
          },
          {
            "_attributes": {
              "beginline": "134",
              "endline": "134",
              "begincolumn": "26",
              "endcolumn": "52",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "135",
              "endline": "135",
              "begincolumn": "17",
              "endcolumn": "35",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "137",
              "endline": "137",
              "begincolumn": "26",
              "endcolumn": "68",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "138",
              "endline": "153",
              "begincolumn": "17",
              "endcolumn": "60",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "variable": "forward",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'forward' (lines '138'-'153').\r\n"
          },
          {
            "_attributes": {
              "beginline": "138",
              "endline": "138",
              "begincolumn": "36",
              "endcolumn": "60",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "139",
              "endline": "139",
              "begincolumn": "24",
              "endcolumn": "32",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          },
          {
            "_attributes": {
              "beginline": "147",
              "endline": "147",
              "begincolumn": "14",
              "endcolumn": "22",
              "rule": "AvoidCatchingGenericException",
              "ruleset": "Strict Exceptions",
              "package": "com.ibatis.struts",
              "class": "BeanAction",
              "method": "execute",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidCatchingGenericException",
              "priority": "3"
            },
            "_text": "\r\nAvoid catching generic exceptions such as NullPointerException, RuntimeException, Exception in try-catch block\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\BeanActionException.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "5",
              "endline": "13",
              "begincolumn": "1",
              "endcolumn": "2",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Too many lines\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "18",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "37",
              "endcolumn": "37",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "variable": "s",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like s\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "30",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "variable": "s",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 's' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "30",
              "endcolumn": "48",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "variable": "throwable",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'throwable' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "26",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "37",
              "endcolumn": "37",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "variable": "s",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like s\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "30",
              "endcolumn": "37",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "variable": "s",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 's' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "40",
              "endcolumn": "58",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "variable": "throwable",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'throwable' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "30",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts",
              "class": "BeanActionException",
              "method": "BeanActionException",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\httpmap\\ApplicationMap.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "26",
              "endcolumn": "32",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "variable": "context",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "11",
              "endcolumn": "33",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "variable": "context",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "ApplicationMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "25",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "ApplicationMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "20",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "ApplicationMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "24",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "getNames",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "29",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "getValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "28",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "27",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "putValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "39",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "putValue",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "32",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "putValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "30",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "removeValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "36",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ApplicationMap",
              "method": "removeValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\httpmap\\BaseHttpMap.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "11",
              "endline": "91",
              "begincolumn": "17",
              "endcolumn": "1",
              "rule": "AbstractNaming",
              "ruleset": "Naming",
              "package": "com.ibatis.struts.httpmap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#AbstractNaming",
              "priority": "3"
            },
            "_text": "\r\nAbstract classes should be named AbstractXXX\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "91",
              "begincolumn": "17",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "91",
              "begincolumn": "50",
              "endcolumn": "1",
              "rule": "TooManyMethods",
              "ruleset": "Code Size",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/codesize.html#TooManyMethods",
              "priority": "3"
            },
            "_text": "\r\nThis class has too many methods, consider refactoring it.\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "15",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "size",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "12",
              "endcolumn": "26",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "size",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "19",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "isEmpty",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "12",
              "endcolumn": "26",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "isEmpty",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "30",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "containsKey",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "23",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "containsKey",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "22",
              "endline": "22",
              "begincolumn": "12",
              "endcolumn": "33",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "containsKey",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "32",
              "endcolumn": "43",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "containsValue",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "27",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "containsValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "12",
              "endcolumn": "35",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "containsValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "21",
              "endcolumn": "30",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "get",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "31",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "get",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "21",
              "endcolumn": "30",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "put",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "33",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "put",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "37",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "put",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "34",
              "endline": "34",
              "begincolumn": "5",
              "endcolumn": "30",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "put",
              "variable": "old",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'old' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "24",
              "endcolumn": "33",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "remove",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "43",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "remove",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "40",
              "endline": "40",
              "begincolumn": "5",
              "endcolumn": "30",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "remove",
              "variable": "old",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'old' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "45",
              "begincolumn": "22",
              "endcolumn": "28",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putAll",
              "variable": "map",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'map' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "51",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putAll",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "14",
              "endcolumn": "14",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putAll",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "5",
              "endcolumn": "40",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putAll",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'i' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "18",
              "endcolumn": "40",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putAll",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "48",
              "endline": "48",
              "begincolumn": "7",
              "endcolumn": "27",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putAll",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'key' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "53",
              "endline": "58",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "14",
              "endcolumn": "14",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "clear",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "5",
              "endcolumn": "36",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "clear",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'i' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "18",
              "endcolumn": "36",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "clear",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "60",
              "endline": "67",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "keySet",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "61",
              "endline": "61",
              "begincolumn": "5",
              "endcolumn": "30",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "keySet",
              "variable": "keySet",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'keySet' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "62",
              "begincolumn": "5",
              "endcolumn": "40",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "keySet",
              "variable": "enumeration",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'enumeration' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "63",
              "begincolumn": "12",
              "endcolumn": "40",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "keySet",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "64",
              "endline": "64",
              "begincolumn": "18",
              "endcolumn": "42",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "keySet",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "69",
              "endline": "76",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "values",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "70",
              "endline": "70",
              "begincolumn": "5",
              "endcolumn": "31",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "values",
              "variable": "list",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'list' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "71",
              "endline": "71",
              "begincolumn": "5",
              "endcolumn": "40",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "values",
              "variable": "enumeration",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'enumeration' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "72",
              "endline": "72",
              "begincolumn": "12",
              "endcolumn": "40",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "values",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "73",
              "endline": "73",
              "begincolumn": "25",
              "endcolumn": "49",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "values",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "78",
              "endline": "80",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "entrySet",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "83",
              "endline": "83",
              "begincolumn": "22",
              "endcolumn": "44",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "getNames",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "85",
              "endline": "85",
              "begincolumn": "22",
              "endcolumn": "49",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "87",
              "endline": "87",
              "begincolumn": "22",
              "endcolumn": "61",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "putValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "89",
              "endline": "89",
              "begincolumn": "22",
              "endcolumn": "50",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "BaseHttpMap",
              "method": "removeValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\httpmap\\CookieMap.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "3",
              "endline": "3",
              "begincolumn": "1",
              "endcolumn": "45",
              "rule": "ImportFromSamePackage",
              "ruleset": "Import Statements",
              "package": "com.ibatis.struts.httpmap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/imports.html#ImportFromSamePackage",
              "priority": "3"
            },
            "_text": "\r\nNo need to import a type that lives in the same package\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "20",
              "endcolumn": "26",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "variable": "cookies",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "11",
              "endcolumn": "27",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "variable": "cookies",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "CookieMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "20",
              "endcolumn": "45",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "CookieMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "CookieMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "26",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getNames",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "29",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "35",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "42",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "11",
              "endcolumn": "42",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "22",
              "endcolumn": "41",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "22",
              "endcolumn": "41",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "9",
              "endcolumn": "37",
              "rule": "OnlyOneReturn",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OnlyOneReturn",
              "priority": "3"
            },
            "_text": "\r\nA method should have only one exit point, and that should be the last statement in the method\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "16",
              "endcolumn": "36",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "16",
              "endcolumn": "36",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "27",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "putValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "39",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "putValue",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "39",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "putValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "41",
              "begincolumn": "30",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "removeValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "41",
              "endline": "43",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap",
              "method": "removeValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "48",
              "endline": "48",
              "begincolumn": "45",
              "endcolumn": "55",
              "rule": "ReplaceEnumerationWithIterator",
              "ruleset": "Migration",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/migrating.html#ReplaceEnumerationWithIterator",
              "priority": "3"
            },
            "_text": "\r\nConsider replacing this Enumeration with the newer java.util.Iterator\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "17",
              "endcolumn": "21",
              "rule": "RedundantFieldInitializer",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#RedundantFieldInitializer",
              "priority": "3"
            },
            "_text": "\r\nAvoid using redundant field initializer for 'i'\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "17",
              "endcolumn": "17",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like i\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "17",
              "endcolumn": "17",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "13",
              "endcolumn": "22",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "variable": "i",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "52",
              "endline": "52",
              "begincolumn": "22",
              "endcolumn": "32",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "variable": "cookieArray",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "52",
              "endline": "52",
              "begincolumn": "13",
              "endcolumn": "33",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "variable": "cookieArray",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "29",
              "endcolumn": "44",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "method": "CookieEnumerator",
              "variable": "cookies",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'cookies' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "29",
              "endcolumn": "44",
              "rule": "ArrayIsStoredDirectly",
              "ruleset": "Security Code Guidelines",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "method": "CookieEnumerator",
              "variable": "cookies",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/sunsecure.html#ArrayIsStoredDirectly",
              "priority": "3"
            },
            "_text": "\r\nThe user-supplied array 'cookies' is stored directly.\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "56",
              "begincolumn": "12",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "method": "CookieEnumerator",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "58",
              "endline": "60",
              "begincolumn": "25",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "method": "hasMoreElements",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "62",
              "endline": "66",
              "begincolumn": "25",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "method": "nextElement",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "63",
              "endline": "63",
              "begincolumn": "7",
              "endcolumn": "37",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "CookieMap$CookieEnumerator",
              "method": "nextElement",
              "variable": "element",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'element' could be declared final\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\httpmap\\ParameterMap.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "3",
              "endline": "3",
              "begincolumn": "1",
              "endcolumn": "45",
              "rule": "ImportFromSamePackage",
              "ruleset": "Import Statements",
              "package": "com.ibatis.struts.httpmap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/imports.html#ImportFromSamePackage",
              "priority": "3"
            },
            "_text": "\r\nNo need to import a type that lives in the same package\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "30",
              "endcolumn": "36",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "11",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "ParameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "23",
              "endcolumn": "48",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "ParameterMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "ParameterMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "25",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "getNames",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "29",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "getValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "32",
              "endcolumn": "41",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "getValues",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "33",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "getValues",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "27",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "putValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "39",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "putValue",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "37",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "putValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "30",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "removeValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "41",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "ParameterMap",
              "method": "removeValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\httpmap\\RequestMap.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "3",
              "endline": "3",
              "begincolumn": "1",
              "endcolumn": "45",
              "rule": "ImportFromSamePackage",
              "ruleset": "Import Statements",
              "package": "com.ibatis.struts.httpmap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/imports.html#ImportFromSamePackage",
              "priority": "3"
            },
            "_text": "\r\nNo need to import a type that lives in the same package\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "30",
              "endcolumn": "36",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "11",
              "endcolumn": "37",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "RequestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "21",
              "endcolumn": "46",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "RequestMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "21",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "RequestMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "25",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "getNames",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "29",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "getValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "29",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "27",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "putValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "31",
              "begincolumn": "39",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "putValue",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "31",
              "endline": "33",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "putValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "30",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "removeValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "37",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "RequestMap",
              "method": "removeValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\ibatis\\struts\\httpmap\\SessionMap.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "3",
              "endline": "3",
              "begincolumn": "1",
              "endcolumn": "45",
              "rule": "ImportFromSamePackage",
              "ruleset": "Import Statements",
              "package": "com.ibatis.struts.httpmap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/imports.html#ImportFromSamePackage",
              "priority": "3"
            },
            "_text": "\r\nNo need to import a type that lives in the same package\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "23",
              "endcolumn": "29",
              "rule": "BeanMembersShouldSerialize",
              "ruleset": "JavaBeans",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "variable": "session",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/javabeans.html#BeanMembersShouldSerialize",
              "priority": "3"
            },
            "_text": "\r\nFound non-transient, non-static member. Please mark as transient or provide accessors.\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "11",
              "endcolumn": "30",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "variable": "session",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nfieldCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CallSuperInConstructor",
              "ruleset": "Controversial",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "SessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#CallSuperInConstructor",
              "priority": "3"
            },
            "_text": "\r\nIt is a good practice to call super() in a constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "21",
              "endcolumn": "46",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "SessionMap",
              "variable": "request",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'request' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "22",
              "begincolumn": "10",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "SessionMap",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "26",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "getNames",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "28",
              "begincolumn": "29",
              "endcolumn": "38",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "getValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "28",
              "endline": "30",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "getValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "27",
              "endcolumn": "36",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "putValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "32",
              "begincolumn": "39",
              "endcolumn": "50",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "putValue",
              "variable": "value",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'value' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "32",
              "endline": "34",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "putValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "30",
              "endcolumn": "39",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "removeValue",
              "variable": "key",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'key' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "38",
              "begincolumn": "13",
              "endcolumn": "3",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.ibatis.struts.httpmap",
              "class": "SessionMap",
              "method": "removeValue",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nprotectedMethodCommentRequirement Required\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\junit\\StockTest.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "6",
              "endline": "6",
              "begincolumn": "1",
              "endcolumn": "33",
              "rule": "UnusedImports",
              "ruleset": "Type Resolution",
              "package": "com.junit",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#UnusedImports",
              "priority": "4"
            },
            "_text": "\r\nAvoid unused imports such as 'org.junit.Assert'\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "42",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "AtLeastOneConstructor",
              "ruleset": "Controversial",
              "package": "com.junit",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#AtLeastOneConstructor",
              "priority": "3"
            },
            "_text": "\r\nEach class should declare at least one constructor\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "1",
              "endcolumn": "3",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.junit",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "17",
              "endcolumn": "59",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.junit",
              "class": "StockTest",
              "method": "testIsItemInStockTG",
              "variable": "dao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'dao' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "33",
              "begincolumn": "16",
              "endcolumn": "9",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.junit",
              "class": "StockTest",
              "method": "testIsItemInStockTG1",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "30",
              "endline": "30",
              "begincolumn": "17",
              "endcolumn": "59",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.junit",
              "class": "StockTest",
              "method": "testIsItemInStockTG1",
              "variable": "dao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'dao' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "40",
              "begincolumn": "16",
              "endcolumn": "9",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.junit",
              "class": "StockTest",
              "method": "testIsItemInStockTG2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "17",
              "endcolumn": "59",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.junit",
              "class": "StockTest",
              "method": "testIsItemInStockTG2",
              "variable": "dao",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'dao' could be declared final\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\tools\\infosys\\validate\\PreDBValidate.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "10",
              "endline": "51",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "50",
              "endcolumn": "58",
              "rule": "SignatureDeclareThrowsException",
              "ruleset": "Type Resolution",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#SignatureDeclareThrowsException",
              "priority": "3"
            },
            "_text": "\r\nA method/constructor shouldnt explicitly throw java.lang.Exception\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "50",
              "endcolumn": "58",
              "rule": "SignatureDeclareThrowsException",
              "ruleset": "Strict Exceptions",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#SignatureDeclareThrowsException",
              "priority": "3"
            },
            "_text": "\r\nA method/constructor shouldnt explicitly throw java.lang.Exception\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "11",
              "begincolumn": "28",
              "endcolumn": "40",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "args",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'args' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "50",
              "begincolumn": "18",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "13",
              "endline": "13",
              "begincolumn": "12",
              "endcolumn": "41",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "userName",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'userName' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "12",
              "endcolumn": "40",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "password",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'password' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "15",
              "endline": "21",
              "begincolumn": "12",
              "endcolumn": "70",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "conn",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'conn' (lines '15'-'21').\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "22",
              "endcolumn": "25",
              "rule": "UnusedLocalVariable",
              "ruleset": "Unused Code",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "stmt",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedLocalVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid unused local variables such as 'stmt'.\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "23",
              "begincolumn": "8",
              "endcolumn": "36",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "stmt",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'stmt' (lines '16'-'23').\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "26",
              "begincolumn": "8",
              "endcolumn": "72",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "rsColumns",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'rsColumns' (lines '17'-'26').\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "35",
              "begincolumn": "8",
              "endcolumn": "58",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "rsTables",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DD'-anomaly for variable 'rsTables' (lines '17'-'35').\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "50",
              "begincolumn": "40",
              "endcolumn": "54",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "rsTables",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'rsTables' (lines '17'-'50').\r\n"
          },
          {
            "_attributes": {
              "beginline": "17",
              "endline": "17",
              "begincolumn": "12",
              "endcolumn": "54",
              "rule": "OneDeclarationPerLine",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "rsColumns",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#OneDeclarationPerLine",
              "priority": "4"
            },
            "_text": "\r\nUse one line for each declaration, it enhances code readability.\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "12",
              "endcolumn": "96",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "url",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'url' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "50",
              "begincolumn": "8",
              "endcolumn": "36",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "stmt",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'stmt' (lines '23'-'50').\r\n"
          },
          {
            "_attributes": {
              "beginline": "23",
              "endline": "23",
              "begincolumn": "15",
              "endcolumn": "36",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "8",
              "endcolumn": "55",
              "rule": "PrematureDeclaration",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "queryString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#PrematureDeclaration",
              "priority": "3"
            },
            "_text": "\r\nAvoid declaring a variable if it is unreferenced before a possible exit point.\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "15",
              "endcolumn": "25",
              "rule": "UnusedLocalVariable",
              "ruleset": "Unused Code",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "queryString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unusedcode.html#UnusedLocalVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid unused local variables such as 'queryString'.\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "50",
              "begincolumn": "15",
              "endcolumn": "55",
              "rule": "DataflowAnomalyAnalysis",
              "ruleset": "Controversial",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "queryString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#DataflowAnomalyAnalysis",
              "priority": "5"
            },
            "_text": "\r\nFound 'DU'-anomaly for variable 'queryString' (lines '24'-'50').\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "8",
              "endcolumn": "55",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "queryString",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'queryString' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "8",
              "endcolumn": "48",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "variable": "md2",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'md2' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "31",
              "endcolumn": "48",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "26",
              "endline": "26",
              "begincolumn": "20",
              "endcolumn": "72",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "12",
              "endcolumn": "27",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "22",
              "endcolumn": "30",
              "rule": "AvoidThrowingRawExceptionTypes",
              "ruleset": "Strict Exceptions",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidThrowingRawExceptionTypes",
              "priority": "1"
            },
            "_text": "\r\nAvoid throwing raw exception types.\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "19",
              "endcolumn": "58",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "36",
              "endline": "36",
              "begincolumn": "12",
              "endcolumn": "26",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "42",
              "endline": "42",
              "begincolumn": "22",
              "endcolumn": "30",
              "rule": "AvoidThrowingRawExceptionTypes",
              "ruleset": "Strict Exceptions",
              "package": "com.tools.infosys.validate",
              "class": "PreDBValidate",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidThrowingRawExceptionTypes",
              "priority": "1"
            },
            "_text": "\r\nAvoid throwing raw exception types.\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "com\\tools\\infosys\\validate\\PreDeploy.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "13",
              "endline": "66",
              "begincolumn": "8",
              "endcolumn": "1",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\nheaderCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "58",
              "endcolumn": "66",
              "rule": "SignatureDeclareThrowsException",
              "ruleset": "Type Resolution",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/typeresolution.html#SignatureDeclareThrowsException",
              "priority": "3"
            },
            "_text": "\r\nA method/constructor shouldnt explicitly throw java.lang.Exception\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "58",
              "endcolumn": "66",
              "rule": "SignatureDeclareThrowsException",
              "ruleset": "Strict Exceptions",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#SignatureDeclareThrowsException",
              "priority": "3"
            },
            "_text": "\r\nA method/constructor shouldnt explicitly throw java.lang.Exception\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "16",
              "begincolumn": "36",
              "endcolumn": "48",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "argv",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'argv' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "16",
              "endline": "64",
              "begincolumn": "26",
              "endcolumn": "17",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "18",
              "begincolumn": "25",
              "endcolumn": "57",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "fXmlFile",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'fXmlFile' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "25",
              "endcolumn": "95",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "dbFactory",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'dbFactory' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "25",
              "endcolumn": "81",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "dBuilder",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'dBuilder' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "25",
              "endcolumn": "63",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "doc",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'doc' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "24",
              "endline": "24",
              "begincolumn": "1",
              "endcolumn": "3",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "25",
              "endcolumn": "60",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "25",
              "endline": "25",
              "begincolumn": "25",
              "endcolumn": "60",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "25",
              "endcolumn": "101",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "63",
              "endcolumn": "100",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "27",
              "endline": "27",
              "begincolumn": "63",
              "endcolumn": "100",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "25",
              "endcolumn": "77",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "nList",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'nList' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "29",
              "endline": "29",
              "begincolumn": "42",
              "endcolumn": "77",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "33",
              "endline": "33",
              "begincolumn": "51",
              "endcolumn": "67",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "33",
              "endcolumn": "61",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "nNode",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'nNode' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "35",
              "endline": "35",
              "begincolumn": "46",
              "endcolumn": "61",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "37",
              "endline": "37",
              "begincolumn": "76",
              "endcolumn": "94",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "38",
              "endline": "38",
              "begincolumn": "33",
              "endcolumn": "66",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "variable": "eElement",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'eElement' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "39",
              "endline": "39",
              "begincolumn": "37",
              "endcolumn": "55",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "43",
              "endline": "43",
              "begincolumn": "76",
              "endcolumn": "108",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "44",
              "endline": "44",
              "begincolumn": "76",
              "endcolumn": "108",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "45",
              "endline": "45",
              "begincolumn": "83",
              "endcolumn": "122",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "46",
              "endline": "46",
              "begincolumn": "71",
              "endcolumn": "98",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "48",
              "endline": "48",
              "begincolumn": "1",
              "endcolumn": "3",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "49",
              "endline": "49",
              "begincolumn": "1",
              "endcolumn": "3",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "50",
              "endline": "50",
              "begincolumn": "1",
              "endcolumn": "3",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "51",
              "endline": "51",
              "begincolumn": "1",
              "endcolumn": "3",
              "rule": "CommentSize",
              "ruleset": "Comments",
              "package": "com.tools.infosys.validate",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentSize",
              "priority": "3"
            },
            "_text": "\r\nComment is too large: Line too long\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "37",
              "endcolumn": "88",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "94",
              "endcolumn": "145",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "151",
              "endcolumn": "222",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "228",
              "endcolumn": "302",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "37",
              "endcolumn": "88",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "94",
              "endcolumn": "145",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "151",
              "endcolumn": "222",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "228",
              "endcolumn": "302",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "37",
              "endcolumn": "88",
              "rule": "UselessParentheses",
              "ruleset": "Unnecessary",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unnecessary.html#UselessParentheses",
              "priority": "4"
            },
            "_text": "\r\nUseless parentheses.\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "94",
              "endcolumn": "145",
              "rule": "UselessParentheses",
              "ruleset": "Unnecessary",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unnecessary.html#UselessParentheses",
              "priority": "4"
            },
            "_text": "\r\nUseless parentheses.\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "151",
              "endcolumn": "222",
              "rule": "UselessParentheses",
              "ruleset": "Unnecessary",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unnecessary.html#UselessParentheses",
              "priority": "4"
            },
            "_text": "\r\nUseless parentheses.\r\n"
          },
          {
            "_attributes": {
              "beginline": "54",
              "endline": "54",
              "begincolumn": "228",
              "endcolumn": "302",
              "rule": "UselessParentheses",
              "ruleset": "Unnecessary",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/unnecessary.html#UselessParentheses",
              "priority": "4"
            },
            "_text": "\r\nUseless parentheses.\r\n"
          },
          {
            "_attributes": {
              "beginline": "60",
              "endline": "60",
              "begincolumn": "51",
              "endcolumn": "59",
              "rule": "AvoidThrowingRawExceptionTypes",
              "ruleset": "Strict Exceptions",
              "package": "com.tools.infosys.validate",
              "class": "PreDeploy",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/strictexception.html#AvoidThrowingRawExceptionTypes",
              "priority": "1"
            },
            "_text": "\r\nAvoid throwing raw exception types.\r\n"
          }
        ]
      },
      {
        "_attributes": {
          "name": "test\\GetCategoryWithProductsTest.java"
        },
        "violation": [
          {
            "_attributes": {
              "beginline": "11",
              "endline": "12",
              "begincolumn": "12",
              "endcolumn": "5",
              "rule": "UnnecessaryConstructor",
              "ruleset": "Controversial",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "GetCategoryWithProductsTest",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/controversial.html#UnnecessaryConstructor",
              "priority": "3"
            },
            "_text": "\r\nAvoid unnecessary constructors - the compiler will generate these for you\r\n"
          },
          {
            "_attributes": {
              "beginline": "11",
              "endline": "12",
              "begincolumn": "12",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "GetCategoryWithProductsTest",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "14",
              "begincolumn": "30",
              "endcolumn": "42",
              "rule": "MethodArgumentCouldBeFinal",
              "ruleset": "Optimization",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "main",
              "variable": "args",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#MethodArgumentCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nParameter 'args' is not assigned and could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "14",
              "endline": "16",
              "begincolumn": "19",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "main",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "22",
              "begincolumn": "5",
              "endcolumn": "5",
              "rule": "JUnit4TestShouldUseTestAnnotation",
              "ruleset": "Migration",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/migrating.html#JUnit4TestShouldUseTestAnnotation",
              "priority": "3"
            },
            "_text": "\r\nJUnit 4 tests that execute tests should use the @Test annotation\r\n"
          },
          {
            "_attributes": {
              "beginline": "18",
              "endline": "22",
              "begincolumn": "12",
              "endcolumn": "5",
              "rule": "CommentRequired",
              "ruleset": "Comments",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "test",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/comments.html#CommentRequired",
              "priority": "3"
            },
            "_text": "\r\npublicMethodCommentRequirement Required\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "18",
              "endcolumn": "18",
              "rule": "ShortVariable",
              "ruleset": "Naming",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "test",
              "variable": "c",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/naming.html#ShortVariable",
              "priority": "3"
            },
            "_text": "\r\nAvoid variables with short names like c\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "9",
              "endcolumn": "83",
              "rule": "LocalVariableCouldBeFinal",
              "ruleset": "Optimization",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "test",
              "variable": "c",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/optimizations.html#LocalVariableCouldBeFinal",
              "priority": "3"
            },
            "_text": "\r\nLocal variable 'c' could be declared final\r\n"
          },
          {
            "_attributes": {
              "beginline": "19",
              "endline": "19",
              "begincolumn": "22",
              "endcolumn": "83",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "test",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (method chain calls)\r\n"
          },
          {
            "_attributes": {
              "beginline": "20",
              "endline": "20",
              "begincolumn": "70",
              "endcolumn": "86",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "test",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          },
          {
            "_attributes": {
              "beginline": "21",
              "endline": "21",
              "begincolumn": "61",
              "endcolumn": "75",
              "rule": "LawOfDemeter",
              "ruleset": "Coupling",
              "package": "test",
              "class": "GetCategoryWithProductsTest",
              "method": "test",
              "externalInfoUrl": "https://pmd.github.io/pmd-5.4.0/pmd-java/rules/java/coupling.html#LawOfDemeter",
              "priority": "3"
            },
            "_text": "\r\nPotential violation of Law of Demeter (object not created locally)\r\n"
          }
        ]
      }
    ]
  }
}

app.get('/report/pmd', function (req, res) {
  console.log('I received a GET request');



  db.results.find(function (err, docs) {
    if(err){
      res.send(err);
      console.log(err);
    }else{
      console.log(docs[0]);
    }

    res.json(docs);
  });
});

app.post('/contactlist', function (req, res) {
  console.log(req.body);
  db.details.insert(obj, function(err, doc) {
    if(err){
      console.log("shitttttttttttttttttttttttttttttttttt");
      console.log(err);
    }
    res.json(doc);
  });
});

app.delete('/contactlist/:id', function (req, res) {
  var id = req.params.id;
  console.log(id);
  db.contactlist.remove({_id: mongojs.ObjectId(id)}, function (err, doc) {
    res.json(doc);
  });
});

app.get('/contactlist/:id', function (req, res) {
  var id = req.params.id;
  console.log(id);
  db.contactlist.findOne({_id: mongojs.ObjectId(id)}, function (err, doc) {
    res.json(doc);
  });
});

app.put('/contactlist/:id', function (req, res) {
  var id = req.params.id;
  console.log(req.body.name);
  db.contactlist.findAndModify({
    query: {_id: mongojs.ObjectId(id)},
    update: {$set: {name: req.body.name, email: req.body.email, number: req.body.number}},
    new: true}, function (err, doc) {
      res.json(doc);
    }
  );
});

app.listen(3000);
console.log("Server running on port 3000");

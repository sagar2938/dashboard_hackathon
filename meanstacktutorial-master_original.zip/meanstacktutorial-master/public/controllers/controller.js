var myApp = angular.module('myApp', []);
myApp.controller('AppCtrl', ['$scope', '$http', function($scope, $http) {
    console.log("Hello World from controller");



var refresh = function() {
  $http.get('report/pmd').success(function(response) {
    console.log("I got the data I requested");
    $scope.errorList = response;
    var points=[];
    var points2=[];
    var points3=[];
  for(var i=0;i<response.length;i++){
      var obj={
        y:response[i].pmd.file.length,
        indexLabel:response[i].pmd._attributes.timestamp
      };
      var violoatiosTotal=0;
      for(var j=0;j<response[i].pmd.file.length;j++){
        var name=response[i].pmd.file[j]._attributes.name.split("\\");
        //console.log(response[i].pmd.file[j]._attributes.name.split("\\"))
        var obj2={

          y:response[i].pmd.file[j].violation.length,
          data:response[i].pmd.file[j]._attributes.name,
          violations:response[i].pmd.file[j].violation
          //indexLabel:name[name.length-1]
        };
        violoatiosTotal=response[i].pmd.file[j].violation.length+violoatiosTotal;
        points2.push(obj2);
      }
      //console.log(points2);
      var timeArray=response[i].pmd._attributes.timestamp.split("T")[0].split("-");
      console.log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
      console.log(timeArray);
      var obj3={
        y:violoatiosTotal,
        x:/*response[i].pmd._attributes.timestamp*/ new Date(parseInt(timeArray[0]),parseInt(timeArray[1]), parseInt(timeArray[2])),
        label:"mon"+i//new Date(parseInt(timeArray[0]),parseInt(timeArray[1]), parseInt(timeArray[2])),

      }
      points3.push(obj3);
    //points3.push(obj);
      points.push(obj);
      console.log("length-------------------------------------->  "+points3.length);
    }
    $scope.points3=points3;
    var chart0 = new CanvasJS.Chart("chartContainer1",
      {
        theme: "theme2",
        title:{
          text: "Gaming Consoles Sold in 2012"
        },
        data: [
        {
          type: "pie",
          showInLegend: true,
          toolTipContent: "{y} - #percent %",
          yValueFormatString: "#0.#,,. Million",
          legendText: "{indexLabel}",
          dataPoints: points
        }
        ]
      });

      chart0.render();

      var chart5 = new CanvasJS.Chart("chartContainer5", {
				title: {
					text: "Column Chart with Index Label and Data Point Width"
				},
				axisX: {
					interval: 10
				},
				dataPointWidth: 60,
				data: [{
					type: "column",
					indexLabelLineThickness: 2,
					dataPoints: points3
				}]
			});
			chart5.render();
/*
  var chart3 = new CanvasJS.Chart("chartContainer3",
   {
     title:{
     text: "Line Chart with Different Color in a Section"
     },
     data: [
     {
       type: "line",
       dataPoints: points3
     }
     ]
   });

   chart3.render();*/

      var chart2 = new CanvasJS.Chart("chartContainer2",
        {
          theme: "theme2",
          title:{
            text: "Gaming Consoles Sold in 2012"
          },
          data: [
          {
            type: "pie",
            //showInLegend: false,
            toolTipContent: "{y} - #percent %--{data}",
            yValueFormatString: "#. Voilations",
            //legendText: "{indexLabel}",
            click:function(e){
              console.log(e);
//    alert(  e.dataSeries.type+ ", dataPoint { x:" + e.dataPoint.x + ", y: "+ e.dataPoint.y + " }" );
check(e);
   } ,
            dataPoints: points2
          }
          ]
        });
        chart2.render();


    $scope.contact = "";
  });
};
var check=function(e){
  console.log("yooooooooooooooooooooo");
  console.log(e);
  console.log("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT");

}
$scope.check=check;
refresh();

$scope.addContact = function() {
  console.log($scope.contact);
  $http.post('/contactlist', $scope.contact).success(function(response) {
    console.log(response);
    refresh();
  });
};

$scope.remove = function(id) {
  console.log(id);
  $http.delete('/contactlist/' + id).success(function(response) {
    refresh();
  });
};

$scope.edit = function(id) {
  console.log(id);
  $http.get('/contactlist/' + id).success(function(response) {
    $scope.contact = response;
  });
};

$scope.update = function() {
  console.log($scope.contact._id);
  $http.put('/contactlist/' + $scope.contact._id, $scope.contact).success(function(response) {
    refresh();
  })
};

$scope.deselect = function() {
  $scope.contact = "";
}

}]);﻿

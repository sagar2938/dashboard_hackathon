var express=require('express');
var app=express();
var path=require('path');

var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/dashboard';
var dbObj;
//var db=require('./mongoop');
MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  dbObj=db;
  console.log("db coonected");
});
/*
MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  console.log("Connected correctly to server");

  insertDocuments(db, function() {
    db.close();
  });
});*/


app.use(express.static('../'));


//var display_posts=require('./display_posts');
app.get('/getPosts/:type',function(req,res){
//var db=require('./mongoop');
/*
  var fs=require('fs');
  var xmlstream=require('xml-stream');
  var stream=fs.createReadStream();
  var xml=new xmlStream(stream);
  xml.preserve('id',true);
  xml.collect('subitem');
  xml.on('endElement:id',function(item){

  });*/
  /*findDocuments(dbObj,function(err,data){
    if(err){
      res.send(err);
    }else{
      res.send(data[0].pmd.file);
    }
  })*/
});
app.get('/',function(req,res){
  console.log("got the get..............................................");
  //  res.send({"a":"a"});
  res.sendFile(path.join('../'+'index.html'));
});


app.get('/badges',function(req,res){


var docs=[];

  var getbadges=function(db){
    console.log("called");
   var cursor =db.collection('badges').find( );
   cursor.each(function(err, doc) {
      assert.equal(err, null);
      if (doc != null) {
        //console.log(doc);
        docs.push(doc);
         //res.json(doc);

      } else {
      //  console.log("error occured");
      }
   });
   res.json(docs)
 }
 getbadges(dbObj);









/*
  var parseString = require('xml2js').parseString;
  var fs=require('fs');
  fs.readFile('../dumplist/PostHistory.xml',function(err,xml){
    parseString(xml,function(err,result){
      //console.log(JSON.stringify(result));
      console.log(result.posthistory.row);
      res.send(result.posthistory.row[0].$);


      //res.send(JSON.parse(JSON.stringify(result.badges.row)));
    });
  });*/
  /*
  var xml = '<?xml version="1.0" encoding="UTF-8" ?><business><company>Code Blog</company><owner>Nic Raboy</owner><employee><firstname>Nic</firstname><lastname>Raboy</lastname></employee><employee><firstname>Maria</firstname><lastname>Campos</lastname></employee></business>';
  parseString(xml, function (err, result) {
      console.log(JSON.stringify(result));
  });*/
  /*
  var fs = require('fs');
var Parser = require('xml2js-parser');

var parser = new Parser({trim: true});
fs.readFile('../dumplist/badges.xml', (err, xml) => {
  parser.parseString(xml, (err, result) => {
    console.log(result);
    res.send(result);
  });
});*/
});






app.listen(8080,function(){
  console.log('listenting at 8080')
});

var findDocuments = function(db, callback) {
  // Get the documents collection
  var collection = db.collection('results');
  // Find some documents
  collection.find({}).toArray(function(err, docs) {
    if(err){
      console.log("error occured while fetching docs");
      console.log(err);
      callback(err);
    }else{
      console.log(docs);
      console.log("successfully fetched docsssssssssssssssssssssssssss");
    }
    callback(null,docs);
  });
}

var parseString = require('xml2js').parseString;
var xml = "<root>Hello xml2js!</root>"
parseString(xml, function (err, result) {
    //console.dir(result);
    console.log(err);
    console.log(result);
});

exports.parseString=parseString;

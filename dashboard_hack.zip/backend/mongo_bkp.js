var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/dashboard';
console.log("yaaa");
//var xml2json=require('xml2json');
//var xmlToJSON=require('xmltojson');
//var libxmljs=require('libxmljs');
var convert = require('xml-js');
var insertDocument = function(db, callback) {
  console.log("yayyyy");

  var parseString = require('xml2js').parseString;


  var fs=require('fs');
  fs.readFile('../dumplist/dump1.xml',function(err,xml){
    //var parseString=xml2json.parseString(xml);
    //var parseString = xml2json.toJson(xml);
    //console.log(parseString);
    //console.log("%%%%%%%%%%%%%%%%%%%");
    //var xmlDoc = libxmljs.parseXml(xml);
    //var result = xmlToJSON.xmlToString(xml);
    //console.log(result);
    var result1 = convert.xml2json(xml, {compact: true, spaces: 4});
    //console.log(result1);

    parseString(xml,function(err,result){
      console.log("3333333333333333333333333333333333333");
      console.log(db);
      //console.log(JSON.stringify(result));
      //console.log(result.pmd.file[0].violation);

      db.collection('movie').find({}).toArray(function(err,data){
        if(err){
          console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1");
          console.log(err);
        }
        console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        console.log(data);
      });
      console.log("%^%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
      db.collection('movie').insertOne(result1,function(err,result){
        console.log();
        console.log("inserted");
        if(err){
          console.log("error occured while inserting ");
          console.log(err);
        }else{
          console.log("successssssssssssssssssss");
          console.log(result);
        }
      });

      //console.log("sdfasdf   "+result.badges.row.length);

      //var badges=[];
      /*for(var i=0;i<result.posthistory.row.length;i++){
        badges.push(result.posthistory.row[i].$);
        db.collection('posthistory').insertOne( result.posthistory.row[i].$, function(err, result) {
         assert.equal(err, null);
         console.log("Inserted a document into the restaurants collection.");
         callback();
       });
     }*/

      //res.send(JSON.parse(JSON.stringify(result.badges.row)));
    });
  });



};

MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  console.log(err);
  console.log("connecteddddddddddddddddddddddddddddd");
  insertDocument(db, function() {
      db.close();
  });
});

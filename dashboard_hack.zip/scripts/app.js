var app=angular.module("app",[]);
/*
app.run(function($rootScope,$http){
  $http.get("/badges")
  .then(function(response){
    $rootScope.badges=badges;
  });
});
*/

app.controller("post",function($scope,$rootScope,$http){
var data=[]
  $http.get("/aa")
  .then(function(response){

    console.log("got the data");
    $scope.data=response
    /*
    badges_all=response.data;
    console.log( response.data.length);

    console.log(response.data);
    console.log(typeof response.data.length);

      var categories=[];
      for(var i=0;i<response.data.length;i++){
        console.log(i);
        console.log(response.data[i].Name);
        var found=0;
        for(var j=0;j<categories.length;j++){
          if(categories[j]==response.data[i].Name){
            found=1;
          }
        }
        console.log(found);
        if(found==0){
          console.log('not found');
          categories.push(response.data[i]);
        }
      //  console.log(badges_all[i]['$']);
      }
      console.log("sdfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
      console.log(categories);
    $scope.badges=categories;
*/

  });


});

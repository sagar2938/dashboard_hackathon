var app=angular.module("app",['controllers','ngRoute']);

app.config(function($routeProvider,$locationProvider){
  $routeProvider
  .when("/",{
    templateUrl:"../partials/new.html",
    controller:"pmdController"
  })
  .when("/portfolio",{
    templateUrl:"../partials/index.html",
    controller:"portfolio"
  })
})

// MEAN Stack RESTful API Tutorial - Contact List App
var express = require('express');
var app = express();
var path = require('path');

var mongojs = require('mongojs');
var db = mongojs('dashboard', ['results',"pmd_db"]);
var bodyParser = require('body-parser');
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());



// viewed at http://localhost:8080
app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/index.html'));
});






var obj={};
app.get('/report/pmd', function (req, res) {
  console.log('I received a GET request');



  db.pmd_db.find(function (err, docs) {
    if(err){
      res.send(err);
      console.log(err);
    }else{
      console.log(docs[0]);
    }

    res.json(docs);
  });
});

app.get('/report/pmd/timestamps',function(req,res){
  db.pmd_db.find({},{"pmd._attributes.timestamp":1},function(err,timestamps){
    if(err){
      console.log("some error occured while fetching timestamps from db")
      res.send("some error occured");
    }else{
      res.send(timestamps);
    }
  })
});

app.get('/report/pmd/fileCount/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd._attributes.timestamp":req.params.timestamp},{"pmd.file._attributes.name":1},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      console.log(files);
      var result={fileCount:files[0].pmd.file.length};
      res.send(result);
    }
  })
});
app.get('/report/pmd/fileList/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd._attributes.timestamp":req.params.timestamp},{"pmd.file._attributes.name":1},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      res.send(files[0].pmd.file);
    }
  })
});

app.get('/report/pmd/violations/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd._attributes.timestamp":req.params.timestamp},function(err,data){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var j=0;j<data.length;j++){
        for(var i=0;i<files[j].pmd.file.length;i++){
          voilations=voilations+files[j].pmd.file[i].violation.length;
        }
      }

      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/violations/file/:file/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file._attributes.name":req.params.file,"pmd._attributes.timestamp":req.params.timestamp},function(err,violations){
    if(err){
      console.log(err);
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var noViolation=0;
      for(var i=0;i<violations[0].pmd.file.length;i++){
        noViolation=noViolation+violations[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:noViolation};

      res.send(result);
    }
  })
});



app.get('/report/pmd/priorities/',function(req,res){
  db.pmd_db.distinct("pmd.file.violation._attributes.priority",function(err,priorities){
    if(err){
      console.log("some error occured while fetching priorities from db")
      res.send("some error occured");
    }else{
      res.send(priorities);
    }
  })
});

app.get('/report/pmd/rules/',function(req,res){
  db.pmd_db.distinct("pmd.file.violation._attributes.rule",function(err,rules){
    if(err){
      console.log("some error occured while fetching rules from db")
      res.send("some error occured");
    }else{
      res.send(rules);
    }
  })
});

app.get('/report/pmd/ruleset/',function(req,res){
  db.pmd_db.distinct("pmd.file.violation._attributes.ruleset",function(err,ruleset){
    if(err){
      console.log("some error occured while fetching ruleset from db")
      res.send("some error occured");
    }else{
      res.send(ruleset);
    }
  })
});

app.get('/report/pmd/package/',function(req,res){
  db.pmd_db.distinct("pmd.file.violation._attributes.package",function(err,packages){
    if(err){
      console.log("some error occured while fetching package from db")
      res.send("some error occured");
    }else{
      res.send(packages);
    }
  })
});

app.get('/report/pmd/class/',function(req,res){
  db.pmd_db.distinct("pmd.file.violation._attributes.class",function(err,classes){
    if(err){
      console.log("some error occured while fetching class from db")
      res.send("some error occured");
    }else{
      res.send(classes);
    }
  })
});

app.get('/report/pmd/text/',function(req,res){
  db.pmd_db.distinct("pmd.file.violation._text",function(err,text){
    if(err){
      console.log("some error occured while fetching text from db")
      res.send("some error occured");
    }else{
      res.send(text);
    }
  })
});

app.get('/report/pmd/priority/:priority/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.priority":req.params.priority,"pmd._attributes.timestamp":req.params.timestamp},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});
app.get('/report/pmd/priority/:priority/file/:file/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.priority":req.params.priority,"pmd._attributes.timestamp":req.params.timestamp,"pmd.file._attributes.name":file},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/timestamp/violation',function(req,res){
  db.pmd_db.find({},function(err,data){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var j=0;j<data.length;j++){
        for(var i=0;i<files[j].pmd.file.length;i++){
          voilations=voilations+files[j].pmd.file[i].violation.length;
        }
      }

      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/timestamp/files',function(req,res){
  db.pmd_db.find({},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var fileCount=0;
      for(var j=0;j<files.length;j++){
        fileCount=fileCount+files[j].pmd.file.length;
      }

      var result={numOffiles:fileCount};
      res.send(result);
    }
  })
});



app.get('/report/pmd/rule/:rule/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.rule":req.params.priority,"pmd._attributes.timestamp":req.params.timestamp},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/rule/:rule/file/:file/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.rule":req.params.priority,"pmd._attributes.timestamp":req.params.timestamp,"pmd.file._attributes.name":file},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});


app.get('/report/pmd/ruleset/:ruleset/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.ruleset":req.params.ruleset,"pmd._attributes.timestamp":req.params.timestamp},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/ruleset/:ruleset/file/:file/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.ruleset":req.params.ruleset,"pmd._attributes.timestamp":req.params.timestamp,"pmd.file._attributes.name":file},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/class/:class/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.class":req.params.class,"pmd._attributes.timestamp":req.params.timestamp},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/class/:class/file/:filetimestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.class":req.params.class,"pmd._attributes.timestamp":req.params.timestamp,"pmd.file._attributes.name":file},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});


app.get('/report/pmd/package/:package/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.package":req.params.priority,"pmd._attributes.timestamp":req.params.timestamp},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});

app.get('/report/pmd/package/:package/file/:file/timestamp/:timestamp',function(req,res){
  db.pmd_db.find({"pmd.file.violation._attributes.package":req.params.priority,"pmd._attributes.timestamp":req.params.timestamp,"pmd.file._attributes.name":file},function(err,files){
    if(err){
      console.log("some error occured while fetching file count from db")
      res.send("some error occured");
    }else{
      console.log("successsssssssssssss");
      //console.log(files);
      //var result={fileCount:files[0].pmd.file.length};
      var voilations=0;
      for(var i=0;i<files[0].pmd.file.length;i++){
        voilations=voilations+files[0].pmd.file[i].violation.length;
      }
      var result={numOfViolations:voilations};
      res.send(result);
    }
  })
});



app.post('/contactlist', function (req, res) {
  console.log(req.body);
  db.details.insert(obj, function(err, doc) {
    if(err){
      console.log("shitttttttttttttttttttttttttttttttttt");
      console.log(err);
    }
    res.json(doc);
  });
});

app.delete('/contactlist/:id', function (req, res) {
  var id = req.params.id;
  console.log(id);
  db.contactlist.remove({_id: mongojs.ObjectId(id)}, function (err, doc) {
    res.json(doc);
  });
});

app.get('/contactlist/:id', function (req, res) {
  var id = req.params.id;
  console.log(id);
  db.contactlist.findOne({_id: mongojs.ObjectId(id)}, function (err, doc) {
    res.json(doc);
  });
});

app.put('/contactlist/:id', function (req, res) {
  var id = req.params.id;
  console.log(req.body.name);
  db.contactlist.findAndModify({
    query: {_id: mongojs.ObjectId(id)},
    update: {$set: {name: req.body.name, email: req.body.email, number: req.body.number}},
    new: true}, function (err, doc) {
      res.json(doc);
    }
  );
});

app.listen(3000);
console.log("Server running on port 3000");

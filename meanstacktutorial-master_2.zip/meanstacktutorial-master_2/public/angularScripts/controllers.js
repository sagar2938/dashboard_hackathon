var controllers=angular.module("controllers",[]);

controllers.controller("pmdController",function($scope,$http){
  $scope.check="checkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk";
});
